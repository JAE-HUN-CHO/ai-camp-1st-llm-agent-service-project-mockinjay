import svgPaths from "./svg-v4nlrye2ns";
import imgEllipse from "figma:asset/a41d0bce69dcf5e5e8ffb4715e64f304ea60ef40.png";
import imgImage from "figma:asset/4e4fdf76b8437f3803d90799bbfb04f9e90b06dd.png";
import imgImage43 from "figma:asset/e716f3384c2867e1f8e429c84073e4eeb52c49ca.png";
import imgImage44 from "figma:asset/43db826ac762225d98b09bb5fa5d5ba450e0db4b.png";

function Group4() {
  return (
    <div className="absolute h-[6px] left-[14px] top-[24px] w-[20px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-33.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 8">
          <g id="Group 42">
            <line id="Line 22" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="1" y2="1" />
            <line id="Line 23" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="7" y2="7" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[161px] top-[18px]">
      <p className="absolute font-['Inter:Bold','Noto_Sans_KR:Bold',sans-serif] font-bold leading-[normal] left-[192px] not-italic text-[14px] text-black text-center top-[18px] translate-x-[-50%] w-[62px]">트렌드</p>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[14px] top-[18px]">
      <Group4 />
      <Group3 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents inset-[1.23%_2.67%_95.32%_89.87%]">
      <div className="absolute inset-[1.23%_2.67%_95.32%_89.87%]" data-name="Ellipse">
        <img alt="" className="block max-w-none size-full" height="28" src={imgEllipse} width="28" />
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute h-[54.484px] left-[83.58px] top-0 w-[41.388px]" data-name="Button">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[22.5px] left-[21px] not-italic text-[#999999] text-[15px] text-center text-nowrap top-[16px] translate-x-[-50%] whitespace-pre">대시보드</p>
    </div>
  );
}

function Container() {
  return <div className="absolute bg-[#9f7aea] h-[1.996px] left-0 top-[52.49px] w-[43.582px]" data-name="Container" />;
}

function Button1() {
  return (
    <div className="absolute h-[54.484px] left-[5px] top-0 w-[43.582px]" data-name="Button">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[22.5px] left-[21.99px] not-italic text-[#00c8b4] text-[15px] text-center text-nowrap top-[16px] translate-x-[-50%] whitespace-pre">새소식</p>
      <Container />
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[54.484px] relative shrink-0 w-full" data-name="Container">
      <Button />
      <Button1 />
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col h-[52px] items-start left-0 pb-[0.551px] pt-0 px-[15.996px] top-[53px] w-[375px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e0e0e0] border-[0px_0px_0.551px] border-solid inset-0 pointer-events-none" />
      <Container1 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[16.67%_12.5%_12.5%_12.5%]" data-name="Group">
      <div className="absolute inset-[-6.28%_-5.93%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 18">
          <g id="Group">
            <path d={svgPaths.p38784f80} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            <path d={svgPaths.pf413680} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function TablerMessageChatbot() {
  return (
    <div className="absolute left-[27.86px] overflow-clip size-[22.482px] top-[763px]" data-name="tabler:message-chatbot">
      <Group />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[22px] top-[763px]">
      <TablerMessageChatbot />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[39.58px] not-italic text-[10px] text-black text-center top-[787.7px] translate-x-[-50%] w-[35.155px]">AI챗봇</p>
    </div>
  );
}

function MaterialSymbolsFoodBankOutlineRounded() {
  return (
    <div className="absolute left-[102.72px] size-[22.482px] top-[763px]" data-name="material-symbols:food-bank-outline-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 23">
        <g id="material-symbols:food-bank-outline-rounded">
          <path d={svgPaths.p175f7400} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[91px] top-[763px]">
      <MaterialSymbolsFoodBankOutlineRounded />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[113.95px] not-italic text-[10px] text-black text-center top-[788.68px] translate-x-[-50%] w-[45.897px]">식단케어</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[8.33%_18.75%]" data-name="Group">
      <div className="absolute inset-[-4%_-5.34%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 21">
          <g id="Group">
            <path d={svgPaths.p1c002700} id="Vector" stroke="var(--stroke-0, black)" strokeWidth="1.5" />
            <path d={svgPaths.pb16100} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p33edda80} id="Vector_3" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="1.5" />
            <path d="M7.76828 11.9909H7.77671" id="Vector_4" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function HugeiconsQuiz() {
  return (
    <div className="absolute left-[171px] size-[22.482px] top-[763px]" data-name="hugeicons:quiz-02">
      <Group1 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[163px] top-[763px]">
      <HugeiconsQuiz />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[13px] leading-[normal] left-[181.5px] not-italic text-[10px] text-black text-center top-[790px] translate-x-[-50%] w-[37px]">퀴즈미션</p>
    </div>
  );
}

function OcticonPeople() {
  return (
    <div className="absolute left-[240.67px] size-[22.482px] top-[763px]" data-name="octicon:people-24">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 23">
        <g id="octicon:people-24">
          <path d={svgPaths.p398a000} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[227px] top-[763px]">
      <OcticonPeople />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[251.9px] not-italic text-[10px] text-black text-center top-[789px] translate-x-[-50%] w-[49.804px]">커뮤니티</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[11.46%]" data-name="Group">
      <div className="absolute inset-[-4.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
          <g id="Group">
            <path d={svgPaths.p181cc100} id="Vector" stroke="var(--stroke-0, black)" strokeWidth="1.5" />
            <path d={svgPaths.p3c4d9f00} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="1.6" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MageDashboardBar() {
  return (
    <div className="absolute left-[322.72px] size-[22.482px] top-[763px]" data-name="mage:dashboard-bar">
      <Group2 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[311px] top-[763px]">
      <MageDashboardBar />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[13.672px] leading-[normal] left-[333.95px] not-italic text-[10px] text-black text-center top-[789.37px] translate-x-[-50%] w-[45.897px]">트렌드</p>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[22px] top-[763px]">
      <Group7 />
      <Group8 />
      <Group9 />
      <Group10 />
      <Group11 />
    </div>
  );
}

function Heading() {
  return <div className="absolute h-[31.195px] left-0 top-0 w-[326.598px]" data-name="Heading 2" />;
}

function Container3() {
  return (
    <div className="absolute h-[56.805px] left-[25px] top-[135px] w-[326.598px]" data-name="Container">
      <Heading />
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute bg-[#f2fffd] h-[28px] left-[8.01px] rounded-[10px] top-[6.01px] w-[50px]" data-name="Container">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[11.99px] not-italic text-[#00c8b4] text-[12px] text-nowrap top-[4px] whitespace-pre">뉴스</p>
    </div>
  );
}

function Image() {
  return (
    <div className="relative shrink-0 size-[127.992px]" data-name="Image (신장 건강 체크 퀴즈)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid box-border inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage} />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border overflow-clip relative rounded-[inherit] size-[127.992px]">
        <Container4 />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="content-stretch flex h-[22.492px] items-start relative shrink-0 w-full" data-name="Heading 3">
      <p className="basis-0 font-['Noto_Sans_KR:Medium',sans-serif] grow leading-[14px] min-h-px min-w-px not-italic relative shrink-0 text-[0px] text-[11px] text-black">
        <span className="font-['Noto_Sans_KR:Bold',sans-serif]">{`2025 미국신장학회 신장주간서 FINE-ONE 3상 연구 결과' 발표`}</span>…
      </p>
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[32px] relative shrink-0 w-[201px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[7.995px] h-[32px] items-start relative w-[201px]">
        <Heading1 />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[21px] relative shrink-0 w-[111px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[21px] relative w-[111px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] h-[15px] leading-[12px] left-[0.03px] not-italic text-[#777777] text-[9px] top-[3.02px] w-[119px]">메디컬헤럴드 | 2일전</p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[19.987px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p30b7c7c0} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66557" />
        </g>
      </svg>
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[21px] relative shrink-0 w-[200.977px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[21px] items-center justify-between relative w-[200.977px]">
        <Text />
        <Icon />
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="basis-0 grow h-[127.992px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col h-[127.992px] items-start justify-between pb-0 pl-[15.989px] pr-0 pt-[15.989px] relative w-full">
          <Container5 />
          <p className="font-['Noto_Sans_KR:Regular',sans-serif] h-[47px] leading-[12px] not-italic relative shrink-0 text-[#272727] text-[9px] w-[204px]">
            FINE-ONE 연구 결과, 1형 당뇨병 동반 만성 신장병 성인 환자를 대상으로 표준치료에 피네레논을 추가 투여 시 위약 대비 베이스라인 이후 6개월 간 요-알부민-크레아티닌 비율(UACR)의 유의한 감소 효과를 확인했다...
            <br aria-hidden="true" />
            <br aria-hidden="true" />
          </p>
          <Container6 />
        </div>
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute content-stretch flex h-[127.992px] items-start left-0 top-0 w-[360.948px]" data-name="Container">
      <Image />
      <Container7 />
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-white h-[127.992px] left-[-5px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-0 w-[360.948px]" data-name="Button">
      <Container8 />
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute bg-[#f2fffd] h-[28px] left-[8.01px] rounded-[10px] top-[6.01px] w-[50px]" data-name="Container">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[11.99px] not-italic text-[#00c8b4] text-[12px] text-nowrap top-[4px] whitespace-pre">뉴스</p>
    </div>
  );
}

function Image1() {
  return (
    <div className="relative shrink-0 size-[127.992px]" data-name="Image (신장 건강 체크 퀴즈)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid box-border inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage} />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border overflow-clip relative rounded-[inherit] size-[127.992px]">
        <Container9 />
        <div className="absolute h-[533px] left-[-336px] top-[-203px] w-[800px]" data-name="image 43">
          <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage43} />
        </div>
      </div>
    </div>
  );
}

function Heading2() {
  return (
    <div className="content-stretch flex h-[22.492px] items-start relative shrink-0 w-full" data-name="Heading 3">
      <p className="basis-0 font-['Noto_Sans_KR:Bold',sans-serif] grow leading-[14px] min-h-px min-w-px not-italic relative shrink-0 text-[11px] text-black">전 세계 CKD 성인환자 8억 명</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="h-[19px] relative shrink-0 w-[201px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[7.995px] h-[19px] items-start relative w-[201px]">
        <Heading2 />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[21px] relative shrink-0 w-[111px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[21px] relative w-[111px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] h-[15px] leading-[12px] left-[0.03px] not-italic text-[#777777] text-[9px] top-[3.02px] w-[119px]">메디컬트리뷴 | 3일전</p>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[19.987px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p30b7c7c0} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66557" />
        </g>
      </svg>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[21px] relative shrink-0 w-[200.977px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[21px] items-center justify-between relative w-[200.977px]">
        <Text1 />
        <Icon1 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="basis-0 grow h-[127.992px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col h-[127.992px] items-start justify-between pb-0 pl-[15.989px] pr-0 pt-[15.989px] relative w-full">
          <Container10 />
          <p className="font-['Noto_Sans_KR:Regular',sans-serif] h-[47px] leading-[12px] not-italic relative shrink-0 text-[#272727] text-[9px] w-[204px]">
            전 세계 만성신장병(Chronic Kidney Disease, CKD) 성인환자가 8억 명으로 30년새 두 배 이상 증가했다는 분석 결과가 나왔다.
            <br aria-hidden="true" />
            <br aria-hidden="true" />
          </p>
          <Container11 />
        </div>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute content-stretch flex h-[127.992px] items-start left-0 top-0 w-[360.948px]" data-name="Container">
      <Image1 />
      <Container12 />
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute bg-[#f2fffd] h-[28px] left-[8px] rounded-[10px] top-[6px] w-[50px]" data-name="Container">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[11.99px] not-italic text-[#00c8b4] text-[12px] text-nowrap top-[4px] whitespace-pre">뉴스</p>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-white h-[127.992px] left-[-4.99px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[150.01px] w-[360.948px]" data-name="Button">
      <Container13 />
      <Container14 />
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute bg-[#f2fffd] h-[28px] left-[8.01px] rounded-[10px] top-[6.01px] w-[50px]" data-name="Container">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[11.99px] not-italic text-[#00c8b4] text-[14px] text-nowrap top-[4px] whitespace-pre">기사</p>
    </div>
  );
}

function Image2() {
  return (
    <div className="relative shrink-0 size-[127.992px]" data-name="Image (신장 건강 체크 퀴즈)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid box-border inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage} />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border overflow-clip relative rounded-[inherit] size-[127.992px]">
        <Container15 />
        <div className="absolute h-[131px] left-[-5px] top-[-2px] w-[157px]" data-name="image 44">
          <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage44} />
        </div>
      </div>
    </div>
  );
}

function Heading3() {
  return (
    <div className="content-stretch flex h-[22.492px] items-start relative shrink-0 w-full" data-name="Heading 3">
      <p className="basis-0 font-['Noto_Sans_KR:Bold',sans-serif] grow leading-[14px] min-h-px min-w-px not-italic relative shrink-0 text-[11px] text-black">만성신장병 급여확대 포시가 제네릭은 되고, 자디앙 안된 이유</p>
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[32px] relative shrink-0 w-[201px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[7.995px] h-[32px] items-start relative w-[201px]">
        <Heading3 />
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[21px] relative shrink-0 w-[111px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[21px] relative w-[111px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] h-[15px] leading-[12px] left-[0.03px] not-italic text-[#777777] text-[9px] top-[3.02px] w-[119px]">메디컬헤럴드 | 2일전</p>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[19.987px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p30b7c7c0} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66557" />
        </g>
      </svg>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[21px] relative shrink-0 w-[200.977px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[21px] items-center justify-between relative w-[200.977px]">
        <Text2 />
        <Icon2 />
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="basis-0 grow h-[127.992px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col h-[127.992px] items-start justify-between pb-0 pl-[15.989px] pr-0 pt-[15.989px] relative w-full">
          <Container16 />
          <p className="font-['Noto_Sans_KR:Regular',sans-serif] h-[47px] leading-[12px] not-italic relative shrink-0 text-[#272727] text-[9px] w-[204px]">
            FINE-ONE 연구 결과, 1형 당뇨병 동반 만성 신장병 성인 환자를 대상으로 표준치료에 피네레논을 추가 투여 시 위약 대비 베이스라인 이후 6개월 간 요-알부민-크레아티닌 비율(UACR)의 유의한 감소 효과를 확인했다...
            <br aria-hidden="true" />
            <br aria-hidden="true" />
          </p>
          <Container17 />
        </div>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute content-stretch flex h-[127.992px] items-start left-0 top-0 w-[360.948px]" data-name="Container">
      <Image2 />
      <Container18 />
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute bg-[#f2fffd] h-[28px] left-[8px] rounded-[10px] top-[6px] w-[50px]" data-name="Container">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[11.99px] not-italic text-[#00c8b4] text-[12px] text-nowrap top-[4px] whitespace-pre">뉴스</p>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-white h-[127.992px] left-[-4.99px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[300.01px] w-[360.948px]" data-name="Button">
      <Container19 />
      <Container20 />
    </div>
  );
}

function Image3() {
  return (
    <div className="relative shrink-0 size-[127.992px]" data-name="Image (신장 건강 체크 퀴즈)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid box-border inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage} />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border size-[127.992px]" />
    </div>
  );
}

function Heading4() {
  return (
    <div className="content-stretch flex h-[22.492px] items-start relative shrink-0 w-full" data-name="Heading 3">
      <p className="basis-0 font-['Noto_Sans_KR:Medium',sans-serif] grow leading-[14px] min-h-px min-w-px not-italic relative shrink-0 text-[0px] text-[11px] text-black">
        <span className="font-['Noto_Sans_KR:Bold',sans-serif]">{`2025 미국신장학회 신장주간서 FINE-ONE 3상 연구 결과' 발표`}</span>…
      </p>
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[32px] relative shrink-0 w-[201px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[7.995px] h-[32px] items-start relative w-[201px]">
        <Heading4 />
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[21px] relative shrink-0 w-[111px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[21px] relative w-[111px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] h-[15px] leading-[12px] left-[0.03px] not-italic text-[#777777] text-[9px] top-[3.02px] w-[119px]">메디컬헤럴드 | 2일전</p>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[19.987px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p30b7c7c0} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66557" />
        </g>
      </svg>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[21px] relative shrink-0 w-[200.977px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[21px] items-center justify-between relative w-[200.977px]">
        <Text3 />
        <Icon3 />
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="basis-0 grow h-[127.992px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col h-[127.992px] items-start justify-between pb-0 pl-[15.989px] pr-0 pt-[15.989px] relative w-full">
          <Container21 />
          <p className="font-['Noto_Sans_KR:Regular',sans-serif] h-[47px] leading-[12px] not-italic relative shrink-0 text-[#272727] text-[9px] w-[204px]">
            FINE-ONE 연구 결과, 1형 당뇨병 동반 만성 신장병 성인 환자를 대상으로 표준치료에 피네레논을 추가 투여 시 위약 대비 베이스라인 이후 6개월 간 요-알부민-크레아티닌 비율(UACR)의 유의한 감소 효과를 확인했다...
            <br aria-hidden="true" />
            <br aria-hidden="true" />
          </p>
          <Container22 />
        </div>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="absolute content-stretch flex h-[127.992px] items-start left-0 top-0 w-[360.948px]" data-name="Container">
      <Image3 />
      <Container23 />
    </div>
  );
}

function Container25() {
  return (
    <div className="absolute bg-[#f2fffd] h-[28px] left-[8px] rounded-[10px] top-[6px] w-[50px]" data-name="Container">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[11.99px] not-italic text-[#00c8b4] text-[12px] text-nowrap top-[4px] whitespace-pre">공공</p>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-white h-[127.992px] left-[-4.99px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[450.01px] w-[360.948px]" data-name="Button">
      <Container24 />
      <Container25 />
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[565.579px] relative shrink-0 w-full" data-name="Container">
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
    </div>
  );
}

function Container27() {
  return (
    <div className="absolute box-border content-stretch flex flex-col h-[676px] items-start left-0 overflow-clip pb-0 pt-[15.989px] px-[15.989px] top-[110px] w-[375px]" data-name="Container">
      <Container26 />
    </div>
  );
}

export default function MobileCommunityList() {
  return (
    <div className="bg-white relative size-full" data-name="mobile_community_list">
      <Group5 />
      <Group12 />
      <Container2 />
      <div className="absolute bg-white h-[60px] left-0 top-[753px] w-[375px]" />
      <Group6 />
      <Container3 />
      <Container27 />
    </div>
  );
}