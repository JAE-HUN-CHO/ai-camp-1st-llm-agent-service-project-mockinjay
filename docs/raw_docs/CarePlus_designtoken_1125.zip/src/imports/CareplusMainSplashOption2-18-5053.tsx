import svgPaths from "./svg-50qiwmsnfj";
import imgImage28 from "figma:asset/94edcf03a48343a4968b0f15d76b0b3fe1300c2d.png";
import imgImage33 from "figma:asset/f28ae6c86d33816393fcfe64500e0a33421e0efe.png";

function Group13() {
  return (
    <div className="absolute h-[6px] left-[14px] top-[25px] w-[20px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-33.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 8">
          <g id="Group 42">
            <line id="Line 22" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="1" y2="1" />
            <line id="Line 23" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="7" y2="7" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents left-[14px] top-[282px]">
      <div className="absolute font-['Inter:Regular','Noto_Sans_KR:Bold','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[normal] left-[185px] not-italic text-[12px] text-black text-center top-[282px] translate-x-[-50%] w-[342px]">
        <p className="mb-0">
          <span className="font-['Inter:Bold','Noto_Sans_KR:Bold','Noto_Sans_KR:Regular',sans-serif] font-bold not-italic">케어플러스</span>
          <span>{`는 신장병 환우, 일반인(간병인), 연구자에게 `}</span>
        </p>
        <p>
          {`신장병 관련 정보를 편리하게 찾도록 돕는 특화 AI 서비스입니다. `}
          <br aria-hidden="true" />
          분야별 Agent를 선택해 맞춤형 정보를 받아보세요.
        </p>
      </div>
    </div>
  );
}

function OcticonPerson() {
  return (
    <div className="absolute left-[334px] size-[24px] top-[14px]" data-name="octicon:person-24">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="octicon:person-24">
          <path d={svgPaths.p6366980} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group25() {
  return (
    <div className="absolute contents left-[334px] top-[14px]">
      <OcticonPerson />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[normal] left-[336px] not-italic text-[11px] text-black text-nowrap top-[39px] whitespace-pre">환우</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[16.67%_12.5%_12.5%_12.5%]" data-name="Group">
      <div className="absolute inset-[-6.28%_-5.93%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 18">
          <g id="Group">
            <path d={svgPaths.p38784f80} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            <path d={svgPaths.pf413680} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function TablerMessageChatbot() {
  return (
    <div className="absolute left-[27.86px] overflow-clip size-[22.482px] top-[763px]" data-name="tabler:message-chatbot">
      <Group />
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute contents left-[22px] top-[763px]">
      <TablerMessageChatbot />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[39.58px] not-italic text-[10px] text-black text-center top-[787.7px] translate-x-[-50%] w-[35.155px]">AI챗봇</p>
    </div>
  );
}

function MaterialSymbolsFoodBankOutlineRounded() {
  return (
    <div className="absolute left-[102.72px] size-[22.482px] top-[763px]" data-name="material-symbols:food-bank-outline-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 23">
        <g id="material-symbols:food-bank-outline-rounded">
          <path d={svgPaths.p175f7400} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute contents left-[91px] top-[763px]">
      <MaterialSymbolsFoodBankOutlineRounded />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[113.95px] not-italic text-[10px] text-black text-center top-[788.68px] translate-x-[-50%] w-[45.897px]">식단케어</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[8.33%_18.75%]" data-name="Group">
      <div className="absolute inset-[-4%_-5.34%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 21">
          <g id="Group">
            <path d={svgPaths.p1c002700} id="Vector" stroke="var(--stroke-0, black)" strokeWidth="1.5" />
            <path d={svgPaths.pb16100} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p33edda80} id="Vector_3" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="1.5" />
            <path d="M7.76828 11.9909H7.77671" id="Vector_4" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function HugeiconsQuiz() {
  return (
    <div className="absolute left-[171px] size-[22.482px] top-[763px]" data-name="hugeicons:quiz-02">
      <Group1 />
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute contents left-[163px] top-[763px]">
      <HugeiconsQuiz />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[13px] leading-[normal] left-[181.5px] not-italic text-[10px] text-black text-center top-[790px] translate-x-[-50%] w-[37px]">퀴즈미션</p>
    </div>
  );
}

function OcticonPeople() {
  return (
    <div className="absolute left-[240.67px] size-[22.482px] top-[763px]" data-name="octicon:people-24">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 23">
        <g id="octicon:people-24">
          <path d={svgPaths.p398a000} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group23() {
  return (
    <div className="absolute contents left-[227px] top-[763px]">
      <OcticonPeople />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[251.9px] not-italic text-[10px] text-black text-center top-[789px] translate-x-[-50%] w-[49.804px]">커뮤니티</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[11.46%]" data-name="Group">
      <div className="absolute inset-[-4.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
          <g id="Group">
            <path d={svgPaths.p181cc100} id="Vector" stroke="var(--stroke-0, black)" strokeWidth="1.5" />
            <path d={svgPaths.p3c4d9f00} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="1.6" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MageDashboardBar() {
  return (
    <div className="absolute left-[322.72px] size-[22.482px] top-[763px]" data-name="mage:dashboard-bar">
      <Group2 />
    </div>
  );
}

function Group24() {
  return (
    <div className="absolute contents left-[311px] top-[763px]">
      <MageDashboardBar />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[13.672px] leading-[normal] left-[333.95px] not-italic text-[10px] text-black text-center top-[789.37px] translate-x-[-50%] w-[45.897px]">트렌드</p>
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute contents left-[22px] top-[763px]">
      <Group20 />
      <Group21 />
      <Group22 />
      <Group23 />
      <Group24 />
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents left-[110px] top-[217px]">
      <div className="absolute left-[110px] size-[48px] top-[217px]" data-name="image 28">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage28} />
      </div>
      <p className="absolute bg-clip-text font-['Inter:Thin',sans-serif] font-thin h-[23px] leading-[20px] left-[151px] not-italic text-[24px] top-[235px] w-[43px]" style={{ WebkitTextFillColor: "transparent", backgroundImage: "url('data:image/svg+xml;utf8,<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' viewBox=\\\'0 0 43 23\\\' preserveAspectRatio=\\\'none\\\'><g transform=\\\'matrix(2.15 0 0 1.15 21.5 11.5)\\\'><foreignObject x=\\\'-190\\\' y=\\\'-190\\\' width=\\\'380\\\' height=\\\'380\\\'><div xmlns=\\\'http://www.w3.org/1999/xhtml\\\' style=\\\'background-image: conic-gradient(from 90deg, rgba(75, 40, 74, 1) 0%, rgba(66, 72, 98, 1) 25%, rgba(57, 104, 123, 1) 50%, rgba(48, 137, 147, 1) 75%, rgba(39, 169, 172, 1) 100%); opacity:1; height: 100%; width: 100%;\\\'></div></foreignObject></g></svg>')" }}>
        are
      </p>
    </div>
  );
}

function Group26() {
  return (
    <div className="absolute contents left-[110px] top-[217px]">
      <Group18 />
      <p className="absolute bg-clip-text font-['Inter:Thin',sans-serif] font-thin h-[23px] leading-[20px] left-[185px] not-italic text-[36px] top-[232px] w-[87px]" style={{ WebkitTextFillColor: "transparent", backgroundImage: "url('data:image/svg+xml;utf8,<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' viewBox=\\\'0 0 87 23\\\' preserveAspectRatio=\\\'none\\\'><g transform=\\\'matrix(4.35 0 0 1.15 43.5 11.5)\\\'><foreignObject x=\\\'-190\\\' y=\\\'-190\\\' width=\\\'380\\\' height=\\\'380\\\'><div xmlns=\\\'http://www.w3.org/1999/xhtml\\\' style=\\\'background-image: conic-gradient(from 90deg, rgba(75, 40, 74, 1) 0%, rgba(66, 72, 98, 1) 25%, rgba(57, 104, 123, 1) 50%, rgba(48, 137, 147, 1) 75%, rgba(39, 169, 172, 1) 100%); opacity:1; height: 100%; width: 100%;\\\'></div></foreignObject></g></svg>')" }}>
        Plus
      </p>
    </div>
  );
}

function RiNotificationLine() {
  return (
    <div className="absolute left-[299px] size-[24px] top-[16px]" data-name="ri:notification-line">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="ri:notification-line">
          <path d={svgPaths.p10dbef80} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[132.82px] top-[368px]">
      <div className="absolute bg-white h-[36px] left-[132.82px] rounded-[8px] top-[368px] w-[106.666px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[132.82px] top-[368px]">
      <Group9 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-[250.92px] top-[368px]">
      <div className="absolute bg-white h-[36px] left-[250.92px] rounded-[8px] top-[368px] w-[104.081px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[250.92px] top-[368px]">
      <Group12 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[132.82px] top-[368px]">
      <Group8 />
      <Group7 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[132.82px] top-[368px]">
      <Group5 />
    </div>
  );
}

function UilBookMedical() {
  return (
    <div className="absolute left-[29px] size-[17px] top-[378px]" data-name="uil:book-medical">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
        <g id="uil:book-medical">
          <path d={svgPaths.p221a6f00} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group27() {
  return (
    <div className="absolute contents left-[29px] top-[378px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[78.5px] not-italic text-[12px] text-black text-center top-[379px] translate-x-[-50%] w-[67px]">의료 복지</p>
      <UilBookMedical />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[16px] top-[368px]">
      <div className="absolute bg-white h-[36px] left-[16px] rounded-[8px] top-[368px] w-[106.666px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <Group27 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[16px] top-[368px]">
      <Group6 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[16px] top-[368px]">
      <Group11 />
      <Group4 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[12.5%_8.33%_0.78%_8.33%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Group">
          <g id="Vector"></g>
          <path clipRule="evenodd" d={svgPaths.p1e4dc680} fill="var(--fill-0, black)" fillRule="evenodd" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function MingcuteBookLine() {
  return (
    <div className="absolute left-[268px] size-[16px] top-[378px]" data-name="mingcute:book-line">
      <Group3 />
    </div>
  );
}

function Group29() {
  return (
    <div className="absolute contents left-[268px] top-[378px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[312px] not-italic text-[12px] text-black text-center top-[378px] translate-x-[-50%] w-[56px]">연구 논문</p>
      <MingcuteBookLine />
    </div>
  );
}

function FluentFood16Regular() {
  return (
    <div className="absolute left-[147px] size-[16px] top-[377px]" data-name="fluent:food-16-regular">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="fluent:food-16-regular">
          <path d={svgPaths.p33f67600} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group28() {
  return (
    <div className="absolute contents left-[147px] top-[377px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[196.5px] not-italic text-[12px] text-black text-center top-[378px] translate-x-[-50%] w-[59px]">식이 영양</p>
      <FluentFood16Regular />
    </div>
  );
}

function Group30() {
  return (
    <div className="absolute contents left-[16px] top-[368px]">
      <Group10 />
      <Group29 />
      <Group28 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-[17px] top-[410px]">
      <div className="absolute bg-white h-[68px] left-[17px] rounded-[8px] top-[410px] w-[343px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[26px] not-italic text-[#9c9c9c] text-[12px] top-[420px] w-[203px]">신장병에 관해 자유롭게 물어보세요</p>
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents left-[25px] top-[446px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[59px] not-italic text-[#9c9c9c] text-[12px] top-[452px] w-[56px]">맞춤 정보:</p>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[116px] not-italic text-[#27a9ac] text-[12px] top-[452px] w-[62px]">신장병 환우</p>
      <div className="absolute h-[24px] left-[25px] top-[447px] w-[23px]" data-name="image 33">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[190.79%] left-[-18.55%] max-w-none top-[-45.39%] w-[1225.74%]" src={imgImage33} />
        </div>
      </div>
      <div className="absolute h-[26px] left-[54px] rounded-[4px] top-[446px] w-[135px]">
        <div aria-hidden="true" className="absolute border border-[#eeeff2] border-solid inset-0 pointer-events-none rounded-[4px]" />
      </div>
    </div>
  );
}

function Group31() {
  return (
    <div className="absolute contents left-[17px] top-[410px]">
      <Group14 />
      <Group16 />
    </div>
  );
}

function IconamoonSendFill() {
  return (
    <div className="absolute left-[330px] size-[17px] top-[449px]" data-name="iconamoon:send-fill">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
        <g id="iconamoon:send-fill">
          <path clipRule="evenodd" d={svgPaths.p13ce6900} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[326px] top-[447px]">
      <div className="absolute bg-gradient-to-b from-[#27a9ac] left-[326px] rounded-[8px] size-[24px] to-[#aa58a6] top-[447px]" />
      <IconamoonSendFill />
    </div>
  );
}

export default function CareplusMainSplashOption() {
  return (
    <div className="bg-gradient-to-b from-[#ffffff] relative size-full to-[#f0feff]" data-name="careplus_main_splash_option2">
      <Group13 />
      <Group15 />
      <Group25 />
      <div className="absolute bg-white h-[60px] left-0 top-[753px] w-[375px]" />
      <Group19 />
      <Group26 />
      <RiNotificationLine />
      <Group30 />
      <Group31 />
      <Group17 />
    </div>
  );
}