import svgPaths from "./svg-gapkak9le6";

function Icon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p29361940} id="Vector" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p33e06580} id="Vector_2" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p203c5100} id="Vector_3" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M4 22H20" id="Vector_4" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p30c79280} id="Vector_5" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p3f521e00} id="Vector_6" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[24px] relative shrink-0 w-[78.086px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[78.086px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[24px] left-0 not-italic text-[16px] text-gray-600 text-nowrap top-[-0.5px] whitespace-pre">완료한 퀴즈</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[12px] h-[24px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon />
      <Text />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[36px] left-0 not-italic text-[30px] text-gray-800 top-0 w-[48px]">1/6</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col gap-[8px] h-[118px] items-start left-0 pb-px pt-[25px] px-[25px] rounded-[16px] top-0 w-[357.328px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container />
      <Paragraph />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p9b81900} id="Vector" stroke="var(--stroke-0, #FFB84D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[63.367px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[63.367px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[24px] left-0 not-italic text-[16px] text-gray-600 text-nowrap top-[-0.5px] whitespace-pre">지식 레벨</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[12px] h-[24px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon1 />
      <Text1 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[36px] left-0 not-italic text-[30px] text-gray-800 text-nowrap top-0 whitespace-pre">레벨 1</p>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col gap-[8px] h-[118px] items-start left-[373.33px] pb-px pt-[25px] px-[25px] rounded-[16px] top-0 w-[357.336px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container2 />
      <Paragraph1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M12 6V12L16 14" id="Vector" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.pace200} id="Vector_2" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[78.086px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[78.086px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[24px] left-0 not-italic text-[16px] text-gray-600 text-nowrap top-[-0.5px] whitespace-pre">획득 포인트</p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex gap-[12px] h-[24px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon2 />
      <Text2 />
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[36px] left-0 not-italic text-[#9f7aea] text-[30px] top-0 w-[74px]">100P</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col gap-[8px] h-[118px] items-start left-[746.66px] pb-px pt-[25px] px-[25px] rounded-[16px] top-0 w-[357.336px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container4 />
      <Paragraph2 />
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[118px] relative shrink-0 w-full" data-name="Container">
      <Container1 />
      <Container3 />
      <Container5 />
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[28px] left-0 not-italic text-[20px] text-gray-800 text-nowrap top-[-0.5px] whitespace-pre">전체 퀴즈</p>
    </div>
  );
}

function Heading1() {
  return (
    <div className="absolute h-[25.195px] left-0 top-0 w-[82.805px]" data-name="Heading 4">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[25.2px] left-0 not-italic text-[18px] text-gray-800 text-nowrap top-[0.5px] whitespace-pre">레벨테스트</p>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-start left-0 top-[33.2px] w-[1014px]" data-name="Paragraph">
      <p className="basis-0 font-['Noto_Sans_KR:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[14px] text-gray-600">나의 신장병 지식 수준을 확인해보세요</p>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[20px] relative shrink-0 w-[58.117px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[58.117px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-gray-500 top-0 w-[59px]">문제 10개</p>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-0 size-[16px] top-[2px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p17f48400} id="Vector" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[20px] relative shrink-0 w-[52.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[52.164px]">
        <Icon3 />
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[20px] not-italic text-[#9f7aea] text-[14px] top-0 w-[33px]">100P</p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[28px] items-center left-0 top-[65.2px] w-[1014px]" data-name="Container">
      <Text3 />
      <Text4 />
    </div>
  );
}

function Container8() {
  return (
    <div className="basis-0 grow h-[93.195px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[93.195px] relative w-full">
        <Heading1 />
        <Paragraph3 />
        <Container7 />
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M9 18L15 12L9 6" id="Vector" stroke="var(--stroke-0, #6B7280)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute content-stretch flex h-[93.195px] items-start justify-between left-[25px] top-[25px] w-[1054px]" data-name="Container">
      <Container8 />
      <Icon4 />
    </div>
  );
}

function Button() {
  return (
    <div className="bg-white h-[143.195px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container9 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="absolute h-[25.195px] left-0 top-0 w-[43.563px]" data-name="Heading 4">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[25.2px] left-0 not-italic text-[18px] text-gray-800 text-nowrap top-[0.5px] whitespace-pre">O/X 퀴즈</p>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-start left-0 top-[33.2px] w-[1014px]" data-name="Paragraph">
      <p className="basis-0 font-['Noto_Sans_KR:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[14px] text-gray-600">신장병의 기본 개념과 관리 방법을 알아봅니다</p>
    </div>
  );
}

function Text5() {
  return (
    <div className="bg-[#f2fffd] h-[28px] relative rounded-[10px] shrink-0 w-[57.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[28px] items-start px-[12px] py-[4px] relative w-[57.75px]">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#00c8b4] text-[14px] text-nowrap whitespace-pre">1레벨</p>
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[20px] relative shrink-0 w-[58.117px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[58.117px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-gray-500 top-0 w-[59px]">문제 10개</p>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-0 size-[16px] top-[2px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p17f48400} id="Vector" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[20px] relative shrink-0 w-[52.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[52.164px]">
        <Icon5 />
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[20px] not-italic text-[#9f7aea] text-[14px] top-0 w-[33px]">100P</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[28px] items-center left-0 top-[65.2px] w-[1014px]" data-name="Container">
      <Text5 />
      <Text6 />
      <Text7 />
    </div>
  );
}

function Container11() {
  return (
    <div className="basis-0 grow h-[93.195px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[93.195px] relative w-full">
        <Heading2 />
        <Paragraph4 />
        <Container10 />
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M9 18L15 12L9 6" id="Vector" stroke="var(--stroke-0, #6B7280)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute content-stretch flex h-[93.195px] items-start justify-between left-[25px] top-[25px] w-[1054px]" data-name="Container">
      <Container11 />
      <Icon6 />
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-white h-[143.195px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container12 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[25.195px] relative shrink-0 w-[43.563px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[25.195px] relative w-[43.563px]">
        <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[25.2px] left-0 not-italic text-[18px] text-gray-800 text-nowrap top-[0.5px] whitespace-pre">O/X 퀴즈</p>
      </div>
    </div>
  );
}

function Text8() {
  return (
    <div className="bg-emerald-100 h-[24px] relative rounded-[10px] shrink-0 w-[38.086px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[38.086px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[16px] left-[8px] not-italic text-[12px] text-emerald-600 text-nowrap top-[4px] whitespace-pre">완료</p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex gap-[12px] h-[25.195px] items-center relative shrink-0 w-full" data-name="Container">
      <Heading3 />
      <Text8 />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="basis-0 font-['Noto_Sans_KR:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[14px] text-gray-600">칼륨 조절이 필요한 식품과 식단 계획</p>
    </div>
  );
}

function Text9() {
  return (
    <div className="bg-[#f2fffd] h-[28px] relative rounded-[10px] shrink-0 w-[57.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[28px] items-start px-[12px] py-[4px] relative w-[57.75px]">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#00c8b4] text-[14px] text-nowrap whitespace-pre">2레벨</p>
      </div>
    </div>
  );
}

function Text10() {
  return (
    <div className="h-[20px] relative shrink-0 w-[58.117px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[58.117px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-gray-500 top-0 w-[59px]">문제 10개</p>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="absolute left-0 size-[16px] top-[2px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p17f48400} id="Vector" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="h-[20px] relative shrink-0 w-[52.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[52.164px]">
        <Icon7 />
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[20px] not-italic text-[#9f7aea] text-[14px] top-0 w-[33px]">100P</p>
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="content-stretch flex gap-[16px] h-[28px] items-center relative shrink-0 w-full" data-name="Container">
      <Text9 />
      <Text10 />
      <Text11 />
    </div>
  );
}

function Container15() {
  return (
    <div className="basis-0 grow h-[93.195px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-[93.195px] items-start relative w-full">
        <Container13 />
        <Paragraph5 />
        <Container14 />
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M9 18L15 12L9 6" id="Vector" stroke="var(--stroke-0, #6B7280)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute content-stretch flex h-[93.195px] items-start justify-between left-[25px] top-[25px] w-[1054px]" data-name="Container">
      <Container15 />
      <Icon8 />
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-white h-[143.195px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container16 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="absolute h-[25.195px] left-0 top-0 w-[43.563px]" data-name="Heading 4">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[25.2px] left-0 not-italic text-[18px] text-gray-800 text-nowrap top-[0.5px] whitespace-pre">3레벨</p>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-start left-0 top-[33.2px] w-[1014px]" data-name="Paragraph">
      <p className="basis-0 font-['Noto_Sans_KR:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[14px] text-gray-600">투석 치료의 종류와 주의사항</p>
    </div>
  );
}

function Text12() {
  return (
    <div className="bg-[#f2fffd] h-[28px] relative rounded-[10px] shrink-0 w-[57.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[28px] items-start px-[12px] py-[4px] relative w-[57.75px]">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#00c8b4] text-[14px] text-nowrap whitespace-pre">3레벨</p>
      </div>
    </div>
  );
}

function Text13() {
  return (
    <div className="h-[20px] relative shrink-0 w-[58.117px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[58.117px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-gray-500 top-0 w-[59px]">문제 10개</p>
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="absolute left-0 size-[16px] top-[2px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p17f48400} id="Vector" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text14() {
  return (
    <div className="h-[20px] relative shrink-0 w-[52.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[52.164px]">
        <Icon9 />
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[20px] not-italic text-[#9f7aea] text-[14px] top-0 w-[33px]">100P</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[28px] items-center left-0 top-[65.2px] w-[1014px]" data-name="Container">
      <Text12 />
      <Text13 />
      <Text14 />
    </div>
  );
}

function Container18() {
  return (
    <div className="basis-0 grow h-[93.195px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[93.195px] relative w-full">
        <Heading4 />
        <Paragraph6 />
        <Container17 />
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M9 18L15 12L9 6" id="Vector" stroke="var(--stroke-0, #6B7280)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute content-stretch flex h-[93.195px] items-start justify-between left-[25px] top-[25px] w-[1054px]" data-name="Container">
      <Container18 />
      <Icon10 />
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-white h-[143.195px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container19 />
    </div>
  );
}

function Heading5() {
  return (
    <div className="absolute h-[25.195px] left-0 top-0 w-[43.563px]" data-name="Heading 4">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[25.2px] left-0 not-italic text-[18px] text-gray-800 text-nowrap top-[0.5px] whitespace-pre">4레벨</p>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-start left-0 top-[33.2px] w-[1014px]" data-name="Paragraph">
      <p className="basis-0 font-['Noto_Sans_KR:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[14px] text-gray-600">신장병 환자가 주의해야 할 약물과 관리</p>
    </div>
  );
}

function Text15() {
  return (
    <div className="bg-[#f2fffd] h-[28px] relative rounded-[10px] shrink-0 w-[57.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[28px] items-start px-[12px] py-[4px] relative w-[57.75px]">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#00c8b4] text-[14px] text-nowrap whitespace-pre">4레벨</p>
      </div>
    </div>
  );
}

function Text16() {
  return (
    <div className="h-[20px] relative shrink-0 w-[58.117px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[58.117px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-gray-500 top-0 w-[59px]">문제 10개</p>
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="absolute left-0 size-[16px] top-[2px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p17f48400} id="Vector" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text17() {
  return (
    <div className="h-[20px] relative shrink-0 w-[52.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[52.164px]">
        <Icon11 />
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[20px] not-italic text-[#9f7aea] text-[14px] top-0 w-[33px]">100P</p>
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[28px] items-center left-0 top-[65.2px] w-[1014px]" data-name="Container">
      <Text15 />
      <Text16 />
      <Text17 />
    </div>
  );
}

function Container21() {
  return (
    <div className="basis-0 grow h-[93.195px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[93.195px] relative w-full">
        <Heading5 />
        <Paragraph7 />
        <Container20 />
      </div>
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M9 18L15 12L9 6" id="Vector" stroke="var(--stroke-0, #6B7280)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute content-stretch flex h-[93.195px] items-start justify-between left-[25px] top-[25px] w-[1054px]" data-name="Container">
      <Container21 />
      <Icon12 />
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-white h-[143.195px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container22 />
    </div>
  );
}

function Heading6() {
  return (
    <div className="absolute h-[25.195px] left-0 top-0 w-[43.563px]" data-name="Heading 4">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[25.2px] left-0 not-italic text-[18px] text-gray-800 text-nowrap top-[0.5px] whitespace-pre">5레벨</p>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-start left-0 top-[33.2px] w-[1014px]" data-name="Paragraph">
      <p className="basis-0 font-['Noto_Sans_KR:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[14px] text-gray-600">심화 신장병 관리 및 최신 치료법</p>
    </div>
  );
}

function Text18() {
  return (
    <div className="bg-[#f2fffd] h-[28px] relative rounded-[10px] shrink-0 w-[57.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[28px] items-start px-[12px] py-[4px] relative w-[57.75px]">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#00c8b4] text-[14px] text-nowrap whitespace-pre">5레벨</p>
      </div>
    </div>
  );
}

function Text19() {
  return (
    <div className="h-[20px] relative shrink-0 w-[58.117px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[58.117px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-0 not-italic text-[14px] text-gray-500 top-0 w-[59px]">문제 10개</p>
      </div>
    </div>
  );
}

function Icon13() {
  return (
    <div className="absolute left-0 size-[16px] top-[2px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p17f48400} id="Vector" stroke="var(--stroke-0, #9F7AEA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text20() {
  return (
    <div className="h-[20px] relative shrink-0 w-[52.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20px] relative w-[52.164px]">
        <Icon13 />
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[20px] left-[20px] not-italic text-[#9f7aea] text-[14px] top-0 w-[33px]">100P</p>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[28px] items-center left-0 top-[65.2px] w-[1014px]" data-name="Container">
      <Text18 />
      <Text19 />
      <Text20 />
    </div>
  );
}

function Container24() {
  return (
    <div className="basis-0 grow h-[93.195px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[93.195px] relative w-full">
        <Heading6 />
        <Paragraph8 />
        <Container23 />
      </div>
    </div>
  );
}

function Icon14() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M9 18L15 12L9 6" id="Vector" stroke="var(--stroke-0, #6B7280)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container25() {
  return (
    <div className="absolute content-stretch flex h-[93.195px] items-start justify-between left-[25px] top-[25px] w-[1054px]" data-name="Container">
      <Container24 />
      <Icon14 />
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-white h-[143.195px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container25 />
    </div>
  );
}

function Container26() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[983.172px] items-start relative shrink-0 w-full" data-name="Container">
      <Heading />
      <Button />
      <Button1 />
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[1269.96px] relative shrink-0 w-full" data-name="Container">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[32px] h-[1269.96px] items-start pb-0 pt-[24px] px-[24px] relative w-full">
          <Container6 />
          <Container26 />
        </div>
      </div>
    </div>
  );
}

function QuizListPage() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col h-[1269.96px] items-start left-[280px] overflow-clip px-[23.5px] py-0 top-[64px] w-[1199px]" data-name="QuizListPage">
      <Container27 />
    </div>
  );
}

function Icon15() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p3f86cd40} fill="var(--fill-0, white)" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container28() {
  return (
    <div className="relative rounded-[1.67772e+07px] shrink-0 size-[43.195px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex items-center justify-center pl-0 pr-[0.008px] py-0 relative size-[43.195px]">
        <Icon15 />
      </div>
    </div>
  );
}

function Text21() {
  return (
    <div className="basis-0 grow h-[32px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[32px] relative w-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[32px] left-0 not-italic text-[24px] text-gray-800 text-nowrap top-[-1px] whitespace-pre">CarePlus</p>
      </div>
    </div>
  );
}

function Logo() {
  return (
    <div className="content-stretch flex gap-[8px] h-[43.195px] items-center relative shrink-0 w-full" data-name="Logo">
      <Container28 />
      <Text21 />
    </div>
  );
}

function Header() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col h-[64px] items-start left-0 pb-0 pl-[24px] pr-[1299.51px] pt-[10.398px] top-0 w-[1479px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#ebebeb] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <Logo />
    </div>
  );
}

function ChatbotIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="ChatbotIcon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="ChatbotIcon">
          <path d={svgPaths.p28e5c180} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.14286" />
        </g>
      </svg>
    </div>
  );
}

function Text22() {
  return (
    <div className="h-[24px] relative shrink-0 w-[44.344px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[44.344px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[22.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">AI챗봇</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <ChatbotIcon />
          <Text22 />
        </div>
      </div>
    </div>
  );
}

function Icon16() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3a2bba00} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p7df6000} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p30991400} id="Vector_3" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M15.8333 4.16667L10 10" id="Vector_4" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text23() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">식단케어</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon16 />
          <Text23 />
        </div>
      </div>
    </div>
  );
}

function Icon17() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3ace1680} id="Vector" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p105cfc80} id="Vector_2" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p312978e0} id="Vector_3" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M3.33333 18.3333H16.6667" id="Vector_4" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p1356a280} id="Vector_5" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p18544000} id="Vector_6" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text24() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#00c8b4] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">퀴즈미션</p>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon17 />
          <Text24 />
        </div>
      </div>
    </div>
  );
}

function Icon18() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p25397b80} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p166b7100} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2241fff0} id="Vector_3" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2c4f400} id="Vector_4" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text25() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">커뮤니티</p>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon18 />
          <Text25 />
        </div>
      </div>
    </div>
  );
}

function Icon19() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3ac0b600} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p3c797180} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text26() {
  return (
    <div className="h-[24px] relative shrink-0 w-[44.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[44.164px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[22.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">트렌드</p>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon19 />
          <Text26 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[279px]" data-name="Navigation">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-full items-start overflow-clip pb-0 pt-[16px] px-[16px] relative rounded-[inherit] w-[279px]">
        <Button6 />
        <Button7 />
        <Button8 />
        <Button9 />
        <Button10 />
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="[grid-area:1_/_1] place-self-stretch relative rounded-[10px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex items-start px-[17px] py-[9px] relative size-full">
          <p className="basis-0 font-['Noto_Sans_KR:Medium',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[#666666] text-[14px] text-center">로그인</p>
        </div>
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="[grid-area:1_/_2] bg-[#00c8b4] place-self-stretch relative rounded-[10px] shrink-0" data-name="Button">
      <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[20px] left-[59.98px] not-italic text-[14px] text-center text-nowrap text-white top-[9px] translate-x-[-50%] whitespace-pre">회원가입</p>
    </div>
  );
}

function Container29() {
  return (
    <div className="gap-[8px] grid grid-cols-[repeat(2,_minmax(0px,_1fr))] grid-rows-[repeat(1,_minmax(0px,_1fr))] h-[38px] relative shrink-0 w-full" data-name="Container">
      <Button11 />
      <Button12 />
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="h-[17.594px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[17.6px] left-0 not-italic text-[11px] text-gray-400 text-nowrap top-[-0.5px] whitespace-pre">© 2025 CareGuide</p>
    </div>
  );
}

function Button13() {
  return (
    <div className="h-[15px] relative shrink-0 w-[27.602px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[15px] items-start relative w-[27.602px]">
        <p className="[text-underline-position:from-font] decoration-solid font-['Noto_Sans_KR:Regular',sans-serif] leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-gray-400 text-nowrap underline whitespace-pre">도움말</p>
      </div>
    </div>
  );
}

function Button14() {
  return (
    <div className="h-[15px] relative shrink-0 w-[18.406px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[15px] items-start relative w-[18.406px]">
        <p className="[text-underline-position:from-font] decoration-solid font-['Noto_Sans_KR:Regular',sans-serif] leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-gray-400 text-nowrap underline whitespace-pre">약관</p>
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="h-[15px] relative shrink-0 w-[76.406px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[15px] items-start relative w-[76.406px]">
        <p className="[text-underline-position:from-font] decoration-solid font-['Noto_Sans_KR:Regular',sans-serif] leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-gray-400 text-nowrap underline whitespace-pre">개인정보 처리방침</p>
      </div>
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex gap-[12px] h-[15px] items-start relative shrink-0 w-full" data-name="Container">
      <Button13 />
      <Button14 />
      <Button15 />
    </div>
  );
}

function Container31() {
  return (
    <div className="box-border content-stretch flex flex-col gap-[8px] h-[56.594px] items-start pb-0 pt-[16px] px-0 relative shrink-0 w-full" data-name="Container">
      <Paragraph9 />
      <Container30 />
    </div>
  );
}

function Container32() {
  return (
    <div className="h-[207.594px] relative shrink-0 w-[279px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1px_0px_0px] border-gray-100 border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[16px] h-[207.594px] items-start pb-0 pt-[17px] px-[16px] relative w-[279px]">
        <Container29 />
        <Container31 />
      </div>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col h-[884px] items-start left-0 pl-0 pr-px py-0 top-[64px] w-[280px]" data-name="Sidebar">
      <div aria-hidden="true" className="absolute border-[0px_1px_0px_0px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <Navigation />
      <Container32 />
    </div>
  );
}

export default function CreateDetailedWireframes() {
  return (
    <div className="bg-white relative size-full" data-name="Create Detailed Wireframes">
      <QuizListPage />
      <Header />
      <Sidebar />
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[31.2px] left-[708px] not-italic text-[20px] text-gray-800 text-nowrap top-[16px] whitespace-pre">퀴즈미션</p>
    </div>
  );
}