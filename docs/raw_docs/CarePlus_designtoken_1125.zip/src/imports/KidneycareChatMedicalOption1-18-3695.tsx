import svgPaths from "./svg-7ey0h3cusg";
import imgImage33 from "figma:asset/f28ae6c86d33816393fcfe64500e0a33421e0efe.png";
import imgImage35 from "figma:asset/1407778ba45085eb6cfe9ede362437b370d988d2.png";

function Group() {
  return (
    <div className="absolute h-[11px] left-[25px] top-[68px] w-[16px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-9.09%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 12">
          <g id="Group 19">
            <g id="Group 18">
              <rect fill="var(--fill-0, #39B1B4)" fillOpacity="0.1" height="9" id="Rectangle 10" rx="1.5" stroke="var(--stroke-0, #27A9AC)" width="13" x="1.5" y="2.5" />
              <g id="Group 17">
                <line id="Line 4" stroke="var(--stroke-0, #AA58A6)" x1="12.5" x2="12.5" y1="4" y2="1" />
                <line id="Line 5" stroke="var(--stroke-0, #AA58A6)" x1="14" x2="11" y1="2.5" y2="2.5" />
              </g>
              <line id="Line 6" stroke="var(--stroke-0, #27A9AC)" x1="5.5" x2="5.5" y1="6" y2="8" />
              <line id="Line 7" stroke="var(--stroke-0, #27A9AC)" x1="10.5" x2="10.5" y1="6" y2="8" />
              <g id="Line 8">
                <path d="M0 7.5H1M15 7.5H16" stroke="var(--stroke-0, #27A9AC)" />
                <path d="M0 7.5H1M15 7.5H16" stroke="var(--stroke-1, #27A9AC)" />
                <path d="M0 7.5H1M15 7.5H16" stroke="var(--stroke-2, #27A9AC)" />
              </g>
            </g>
            <line id="Line 9" stroke="var(--stroke-0, white)" x1="11" x2="14" y1="0.5" y2="0.5" />
            <line id="Line 13" stroke="var(--stroke-0, white)" x1="11" x2="14" y1="4.5" y2="4.5" />
            <line id="Line 10" stroke="var(--stroke-0, white)" x1="13" x2="15" y1="1.5" y2="1.5" />
            <line id="Line 15" stroke="var(--stroke-0, white)" x1="10" x2="12" y1="1.5" y2="1.5" />
            <line id="Line 11" stroke="var(--stroke-0, white)" x1="13" x2="15" y1="3.5" y2="3.5" />
            <line id="Line 14" stroke="var(--stroke-0, white)" x1="10" x2="12" y1="3.5" y2="3.5" />
            <line id="Line 12" stroke="var(--stroke-0, white)" x1="14" x2="15" y1="2.5" y2="2.5" />
            <line id="Line 16" stroke="var(--stroke-0, white)" x1="10" x2="11" y1="2.5" y2="2.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[25px] top-[68px]">
      <Group />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[16px] top-[57px]">
      <div className="absolute bg-[#f0f4ff] h-[80px] left-[16px] rounded-br-[12px] rounded-tl-[12px] rounded-tr-[12px] top-[57px] w-[251px]" />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular','Noto_Sans_KR:Bold',sans-serif] font-normal leading-[normal] left-[48px] not-italic text-[12px] text-black top-[67px] w-[208px]">
        <span>{`신장병 관련 정보를 편리하게 제공하는 AI 서비스 `}</span>
        <span className="font-['Inter:Bold','Noto_Sans_KR:Regular','Noto_Sans_KR:Bold',sans-serif] font-bold">키드니케어</span>입니다. 프로필을 일반인, 신장병 환우, 연구자 중 선택하시면 맞춤형 정보를 드려요.
      </p>
      <Group1 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute h-[6px] left-[14px] top-[25px] w-[20px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-33.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 8">
          <g id="Group 42">
            <line id="Line 22" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="1" y2="1" />
            <line id="Line 23" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="7" y2="7" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[152px] top-[18px]">
      <p className="absolute font-['Inter:Bold','Noto_Sans_KR:Bold',sans-serif] font-bold leading-[normal] left-[152px] not-italic text-[14px] text-black top-[18px] w-[56px]">의료 복지</p>
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[125px] top-[147px]">
      <div className="absolute bg-[#27a9ac] h-[36px] left-[125px] rounded-bl-[12px] rounded-tl-[12px] rounded-tr-[12px] top-[147px] w-[234px]" />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[normal] left-[140px] not-italic text-[12px] text-white top-[157px] w-[208px]">떡볶이 먹어도 돼?</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute h-[11.149px] left-[25px] top-[203.15px] w-[16px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-8.97%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 13">
          <g id="Group 19">
            <g id="Group 18">
              <rect fill="var(--fill-0, #39B1B4)" fillOpacity="0.1" height="9.13513" id="Rectangle 10" rx="1.5" stroke="var(--stroke-0, #27A9AC)" width="13" x="1.5" y="2.51372" />
              <g id="Group 17">
                <line id="Line 4" stroke="var(--stroke-0, #AA58A6)" x1="12.5" x2="12.5" y1="4.04086" y2="1.00032" />
                <line id="Line 5" stroke="var(--stroke-0, #AA58A6)" x1="14" x2="11" y1="2.51383" y2="2.51383" />
              </g>
              <line id="Line 6" stroke="var(--stroke-0, #27A9AC)" x1="5.5" x2="5.5" y1="6.06778" y2="8.09481" />
              <line id="Line 7" stroke="var(--stroke-0, #27A9AC)" x1="10.5" x2="10.5" y1="6.06778" y2="8.09481" />
              <g id="Line 8">
                <path d="M0 7.58805H1M15 7.58805H16" stroke="var(--stroke-0, #27A9AC)" />
                <path d="M0 7.58805H1M15 7.58805H16" stroke="var(--stroke-1, #27A9AC)" />
                <path d="M0 7.58805H1M15 7.58805H16" stroke="var(--stroke-2, #27A9AC)" />
              </g>
            </g>
            <line id="Line 9" stroke="var(--stroke-0, white)" x1="11" x2="14" y1="0.5" y2="0.5" />
            <line id="Line 13" stroke="var(--stroke-0, white)" x1="11" x2="14" y1="4.55416" y2="4.55416" />
            <line id="Line 10" stroke="var(--stroke-0, white)" x1="13" x2="15" y1="1.51362" y2="1.51362" />
            <line id="Line 15" stroke="var(--stroke-0, white)" x1="10" x2="12" y1="1.51362" y2="1.51362" />
            <line id="Line 11" stroke="var(--stroke-0, white)" x1="13" x2="15" y1="3.54065" y2="3.54065" />
            <line id="Line 14" stroke="var(--stroke-0, white)" x1="10" x2="12" y1="3.54065" y2="3.54065" />
            <line id="Line 12" stroke="var(--stroke-0, white)" x1="14" x2="15" y1="2.52713" y2="2.52713" />
            <line id="Line 16" stroke="var(--stroke-0, white)" x1="10" x2="11" y1="2.52713" y2="2.52713" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[25px] top-[203.15px]">
      <Group2 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-[16px] top-[192px]">
      <div className="absolute bg-[#f0f4ff] h-[124px] left-[16px] rounded-br-[12px] rounded-tl-[12px] rounded-tr-[12px] top-[192px] w-[255px]" />
      <div className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[79px] leading-[normal] left-[48px] not-italic text-[12px] text-black top-[202px] w-[208px]">
        <p className="mb-0">떡볶이는 고나트륨, 고칼륨 요리여서 신장병 위험이 있으시다면 피하는게 좋습니다. 그래도 떡볶이를 먹고 싶으시다면 신장병 예방을 위한 요리 방법으로 추천해 드릴까요? 병원에서 검진한 신장병 진단 수치나 영양관리 목표를 등록하신다면 그에 맞춰서 추천해 드릴 수 있습니다.</p>
        <p>&nbsp;</p>
      </div>
      <Group3 />
    </div>
  );
}

function OcticonPerson() {
  return (
    <div className="absolute left-[334px] size-[24px] top-[10px]" data-name="octicon:person-24">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="octicon:person-24">
          <path d={svgPaths.p6366980} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[334px] top-[10px]">
      <OcticonPerson />
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents left-[334px] top-[10px]">
      <Group17 />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[16px] top-[322px]">
      <div className="absolute bg-white h-[29px] left-[16px] rounded-[8px] top-[322px] w-[114px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium h-[12px] leading-[normal] left-[72.5px] not-italic text-[#1f1f1f] text-[10px] text-center top-[330px] translate-x-[-50%] w-[101.298px]">신장병 진단 등록하기</p>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[16px] top-[322px]">
      <Group7 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[139px] top-[322px]">
      <div className="absolute h-[29px] left-[139px] top-[322px] w-[127px]">
        <div className="absolute inset-[-1.72%_-0.39%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 128 30">
            <path d={svgPaths.p26528300} fill="var(--fill-0, white)" id="Rectangle 8" stroke="var(--stroke-0, #EBEBEB)" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium h-[12px] leading-[normal] left-[202.5px] not-italic text-[#1f1f1f] text-[10px] text-center top-[330px] translate-x-[-50%] w-[111px]">영양관리 목표 등록하기</p>
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents left-[139px] top-[322px]">
      <Group9 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[17px] top-[458px]">
      <div className="absolute bg-white h-[68px] left-[17px] rounded-[8px] top-[458px] w-[343px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[26px] not-italic text-[#9c9c9c] text-[12px] top-[468px] w-[203px]">신장병에 관해 자유롭게 물어보세요</p>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents left-[25px] top-[494px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[59px] not-italic text-[#9c9c9c] text-[12px] top-[500px] w-[56px]">맞춤 정보:</p>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[116px] not-italic text-[#27a9ac] text-[12px] top-[500px] w-[62px]">신장병 환우</p>
      <div className="absolute h-[24px] left-[25px] top-[495px] w-[23px]" data-name="image 33">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[190.79%] left-[-18.55%] max-w-none top-[-45.39%] w-[1225.74%]" src={imgImage33} />
        </div>
      </div>
      <div className="absolute h-[26px] left-[54px] rounded-[4px] top-[494px] w-[135px]">
        <div aria-hidden="true" className="absolute border border-[#eeeff2] border-solid inset-0 pointer-events-none rounded-[4px]" />
      </div>
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents left-[17px] top-[458px]">
      <Group10 />
      <Group13 />
    </div>
  );
}

function IconamoonSendFill() {
  return (
    <div className="absolute left-[330px] size-[17px] top-[497px]" data-name="iconamoon:send-fill">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
        <g id="iconamoon:send-fill">
          <path clipRule="evenodd" d={svgPaths.p13ce6900} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-[326px] top-[495px]">
      <div className="absolute bg-gradient-to-b from-[#27a9ac] left-[326px] rounded-[8px] size-[24px] to-[#aa58a6] top-[495px]" />
      <IconamoonSendFill />
    </div>
  );
}

export default function KidneycareChatMedicalOption() {
  return (
    <div className="bg-gradient-to-b from-[#ffffff] relative shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] size-full to-[#f0feff]" data-name="kidneycare_chat_medical_option1">
      <Group4 />
      <Group8 />
      <div className="absolute bottom-0 h-[274px] left-0 w-[375px]" data-name="image 35">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage35} />
      </div>
      <Group5 />
      <div className="absolute flex inset-[2.96%_40.8%_96.55%_57.07%] items-center justify-center">
        <div className="flex-none h-[4px] scale-y-[-100%] w-[8px]">
          <div className="relative size-full" data-name="vector">
            <div className="absolute inset-[-15%_-7.5%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 6">
                <path d="M0.6 4.6L4.6 0.6L8.6 4.6" id="vector" stroke="var(--stroke-0, #1F2023)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Group11 />
      <Group12 />
      <Group15 />
      <Group6 />
      <Group16 />
      <Group18 />
      <Group14 />
    </div>
  );
}