import svgPaths from "./svg-4413fkeiw1";
import imgImage13 from "figma:asset/ae4b2d9e84e858889e12ebaf61578a3e3b0566ee.png";
import imgImage9 from "figma:asset/846b63eb46ba0068e2820e8c0569c177d49f19c9.png";
import imgImage33 from "figma:asset/f28ae6c86d33816393fcfe64500e0a33421e0efe.png";
import imgImage28 from "figma:asset/94edcf03a48343a4968b0f15d76b0b3fe1300c2d.png";
import imgImage8 from "figma:asset/4e94bc5dbc8b4ecdb119bcd07f7514b85fe7a97a.png";

function Group4() {
  return (
    <div className="absolute contents left-[199.02px] top-[209px]">
      <div className="absolute h-[60.679px] left-[199.02px] top-[687.31px] w-[740.738px]" data-name="image 13">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage13} />
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[199.02px] top-[209px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "503.765625", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[503.778px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 504 1">
                <line id="Line 3" stroke="var(--stroke-0, #E6EAED)" x2="503.778" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute h-[27.01px] left-[212.17px] top-[238.83px] w-[233.271px]" data-name="image 9">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage9} />
      </div>
    </div>
  );
}

function Group30() {
  return (
    <div className="absolute contents left-[25px] top-[56.54px]">
      <div className="absolute bg-white h-[29px] left-[25px] top-[56.54px] w-[79px]" />
      <div className="absolute h-[74px] left-[203px] top-[113.54px] w-[749px]" data-name="image 40" />
      <div className="absolute bg-white h-[85px] left-[197px] top-[90.54px] w-[754px]" />
      <div className="absolute bg-white h-[34px] left-[191px] top-[56.54px] w-[225px]" />
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[203px] not-italic text-[14px] text-black top-[67.54px] w-[599px]">AI 챗봇</p>
    </div>
  );
}

function Group31() {
  return (
    <div className="absolute contents left-[25px] top-[56.54px]">
      <Group30 />
    </div>
  );
}

function FluentFood16Regular() {
  return (
    <div className="absolute left-[521.44px] size-[16px] top-[112px]" data-name="fluent:food-16-regular">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="fluent:food-16-regular">
          <path d={svgPaths.p33f67600} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group55() {
  return (
    <div className="absolute contents left-[521.44px] top-[112px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[581.22px] not-italic text-[12px] text-black text-center top-[113px] translate-x-[-50%] w-[71.251px]">식이 영양</p>
      <FluentFood16Regular />
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents left-[452.29px] top-[101px]">
      <div className="absolute bg-white h-[36px] left-[452.29px] rounded-[8px] top-[101px] w-[231.267px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <Group55 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-[452.29px] top-[101px]">
      <Group15 />
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents left-[708.34px] top-[101px]">
      <div className="absolute bg-white h-[36px] left-[708.34px] rounded-[8px] top-[101px] w-[225.662px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[12.5%_8.33%_0.78%_8.33%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Group">
          <g id="Vector"></g>
          <path clipRule="evenodd" d={svgPaths.p1e4dc680} fill="var(--fill-0, black)" fillRule="evenodd" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function MingcuteBookLine() {
  return (
    <div className="absolute left-[777.46px] size-[16px] top-[111px]" data-name="mingcute:book-line">
      <Group />
    </div>
  );
}

function Group56() {
  return (
    <div className="absolute contents left-[777.46px] top-[111px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[830.6px] not-italic text-[12px] text-black text-center top-[111px] translate-x-[-50%] w-[67.628px]">연구 논문</p>
      <MingcuteBookLine />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-[708.34px] top-[101px]">
      <Group18 />
      <Group56 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents left-[452.29px] top-[101px]">
      <Group14 />
      <Group12 />
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[452.29px] top-[101px]">
      <Group9 />
    </div>
  );
}

function UilBookMedical() {
  return (
    <div className="absolute left-[268.72px] size-[18.682px] top-[111.16px]" data-name="uil:book-medical">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19">
        <g id="uil:book-medical">
          <rect fill="#39B1B4" fillOpacity="0.1" height="18.6818" width="18.6818" />
          <path d={svgPaths.p964980} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group54() {
  return (
    <div className="absolute contents left-[268.72px] top-[111.16px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium h-[16.484px] leading-[normal] left-[323.12px] not-italic text-[12px] text-black text-center top-[112.26px] translate-x-[-50%] w-[73.628px]">의료 복지</p>
      <UilBookMedical />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-[199px] top-[101px]">
      <div className="absolute bg-[rgba(57,177,180,0.1)] h-[36px] left-[199px] rounded-[8px] top-[101px] w-[231.267px]">
        <div aria-hidden="true" className="absolute border border-[#00c8b4] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <Group54 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[199px] top-[101px]">
      <Group11 />
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents left-[199px] top-[101px]">
      <Group17 />
      <Group8 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[25px] top-[56.54px]">
      <Group4 />
      <Group31 />
      <Group16 />
    </div>
  );
}

function Group28() {
  return (
    <div className="absolute contents font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[normal] left-[602px] not-italic text-[12px] text-black top-[775px]">
      <p className="absolute left-[743px] top-[775px] w-[109px]">이용약관</p>
      <p className="absolute left-[842px] top-[775px] w-[109px]">개인정보 처리방침</p>
      <p className="absolute left-[602px] top-[775px] w-[109px]">도움말 및 지원</p>
    </div>
  );
}

function Group44() {
  return (
    <div className="absolute contents left-[15px] top-[63px]">
      <div className="absolute bg-white h-[163px] left-[15px] top-[63px] w-[133px]" />
    </div>
  );
}

function Group45() {
  return (
    <div className="absolute contents left-[15px] top-[63px]">
      <Group44 />
    </div>
  );
}

function Group51() {
  return (
    <div className="absolute contents left-[15px] top-[63px]">
      <Group45 />
    </div>
  );
}

function Group38() {
  return (
    <div className="absolute contents left-[59px] top-[75px]">
      <p className="absolute font-['Inter:Semi_Bold','Noto_Sans_KR:Bold',sans-serif] font-semibold h-[14.648px] leading-[normal] left-[59px] not-italic text-[10px] text-black top-[75px] w-[35.155px]">AI챗봇</p>
    </div>
  );
}

function Group43() {
  return (
    <div className="absolute contents left-[59px] top-[75px]">
      <Group38 />
    </div>
  );
}

function MaterialSymbolsFoodBankOutlineRounded() {
  return (
    <div className="absolute left-[26px] size-[18px] top-[110px]" data-name="material-symbols:food-bank-outline-rounded">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="material-symbols:food-bank-outline-rounded">
          <path d={svgPaths.p205d4100} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group39() {
  return (
    <div className="absolute contents left-[26px] top-[110px]">
      <MaterialSymbolsFoodBankOutlineRounded />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[59px] not-italic text-[10px] text-black top-[114px] w-[45.897px]">식단케어</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[8.33%_18.75%]" data-name="Group">
      <div className="absolute inset-[-5%_-6.67%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 17">
          <g id="Group">
            <path d={svgPaths.p15e0f00} id="Vector" stroke="var(--stroke-0, black)" strokeWidth="1.5" />
            <path d={svgPaths.p30bfc600} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p23950a0} id="Vector_3" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="1.5" />
            <path d="M6.36917 9.75H6.37592" id="Vector_4" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function HugeiconsQuiz() {
  return (
    <div className="absolute left-[26px] size-[18px] top-[147px]" data-name="hugeicons:quiz-02">
      <Group1 />
    </div>
  );
}

function Group40() {
  return (
    <div className="absolute contents left-[26px] top-[147px]">
      <HugeiconsQuiz />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14px] leading-[normal] left-[59px] not-italic text-[10px] text-black top-[150px] w-[58px]">퀴즈미션</p>
    </div>
  );
}

function OcticonPeople() {
  return (
    <div className="absolute left-[29px] size-[15px] top-[183px]" data-name="octicon:people-24">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="octicon:people-24">
          <path d={svgPaths.p3bf21c00} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group41() {
  return (
    <div className="absolute contents left-[29px] top-[183px]">
      <OcticonPeople />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[14.648px] leading-[normal] left-[59px] not-italic text-[10px] text-black top-[185px] w-[49.804px]">커뮤니티</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[11.46%]" data-name="Group">
      <div className="absolute inset-[-5.41%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
          <g id="Group">
            <path d={svgPaths.p3998d100} id="Vector" stroke="var(--stroke-0, black)" strokeWidth="1.5" />
            <path d={svgPaths.pd3e4500} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="1.6" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MageDashboardBar() {
  return (
    <div className="absolute left-[27px] size-[18px] top-[216px]" data-name="mage:dashboard-bar">
      <Group2 />
    </div>
  );
}

function Group42() {
  return (
    <div className="absolute contents left-[27px] top-[216px]">
      <MageDashboardBar />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[13.672px] leading-[normal] left-[59px] not-italic text-[10px] text-black top-[220px] w-[45.897px]">트렌드</p>
    </div>
  );
}

function Group46() {
  return (
    <div className="absolute contents left-[26px] top-[75px]">
      <Group43 />
      <Group39 />
      <Group40 />
      <Group41 />
      <Group42 />
    </div>
  );
}

function Group52() {
  return (
    <div className="absolute contents left-[26px] top-[75px]">
      <Group46 />
    </div>
  );
}

function Group47() {
  return (
    <div className="absolute contents left-[26px] top-[75px]">
      <Group52 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[16.67%_12.5%_12.5%_12.5%]" data-name="Group">
      <div className="absolute inset-[-8.82%_-8.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
          <g id="Group">
            <path d={svgPaths.p29a8bc80} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            <path d={svgPaths.pd433c80} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function TablerMessageChatbot() {
  return (
    <div className="absolute left-[28px] overflow-clip size-[16px] top-[74px]" data-name="tabler:message-chatbot">
      <Group3 />
    </div>
  );
}

function Group49() {
  return (
    <div className="absolute contents left-[26px] top-[74px]">
      <Group47 />
      <TablerMessageChatbot />
    </div>
  );
}

function Group48() {
  return (
    <div className="absolute contents left-[26px] top-[74px]">
      <Group49 />
    </div>
  );
}

function Group50() {
  return (
    <div className="absolute contents left-[26px] top-[74px]">
      <Group48 />
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute h-[6px] left-[22px] top-[25px] w-[20px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-33.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 8">
          <g id="Group 42">
            <line id="Line 22" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="1" y2="1" />
            <line id="Line 23" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="7" y2="7" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute contents left-[208px] top-[705px]">
      <div className="absolute bg-white h-[34px] left-[208px] rounded-[8px] top-[705px] w-[725px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[249px] not-italic text-[#9c9c9c] text-[12px] top-[713px] w-[400px]">메시지를 입력하세요</p>
    </div>
  );
}

function Group24() {
  return (
    <div className="absolute contents left-[216px] top-[708px]">
      <div className="absolute h-[24px] left-[216px] top-[708px] w-[23px]" data-name="image 33">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[190.79%] left-[-18.55%] max-w-none top-[-45.39%] w-[1225.74%]" src={imgImage33} />
        </div>
      </div>
    </div>
  );
}

function Group26() {
  return (
    <div className="absolute contents left-[208px] top-[705px]">
      <Group21 />
      <Group24 />
    </div>
  );
}

function IconamoonSendFill() {
  return (
    <div className="absolute left-[909px] size-[17px] top-[713px]" data-name="iconamoon:send-fill">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
        <g id="iconamoon:send-fill">
          <path clipRule="evenodd" d={svgPaths.p13ce6900} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group29() {
  return (
    <div className="absolute contents left-[905px] top-[710px]">
      <div className="absolute bg-gradient-to-b from-[#27a9ac] left-[905px] rounded-[8px] size-[24px] to-[#aa58a6] top-[710px]" />
      <IconamoonSendFill />
    </div>
  );
}

function Group32() {
  return (
    <div className="absolute contents left-[208px] top-[705px]">
      <Group26 />
      <Group29 />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute h-[11.813px] left-[223px] top-[171.18px] w-[16px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-8.47%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 13">
          <g id="Group 19">
            <g id="Group 18">
              <rect fill="var(--fill-0, #39B1B4)" fillOpacity="0.1" height="9.73869" id="Rectangle 10" rx="1.5" stroke="var(--stroke-0, #27A9AC)" width="13" x="1.5" y="2.57442" />
              <g id="Group 17">
                <line id="Line 4" stroke="var(--stroke-0, #AA58A6)" x1="12.5" x2="12.5" y1="4.22217" y2="1.00056" />
                <line id="Line 5" stroke="var(--stroke-0, #AA58A6)" x1="14" x2="11" y1="2.5746" y2="2.5746" />
              </g>
              <line id="Line 6" stroke="var(--stroke-0, #27A9AC)" x1="5.5" x2="5.5" y1="6.36955" y2="8.51729" />
              <line id="Line 7" stroke="var(--stroke-0, #27A9AC)" x1="10.5" x2="10.5" y1="6.36955" y2="8.51729" />
              <g id="Line 8">
                <path d="M0 7.98062H1M15 7.98062H16" stroke="var(--stroke-0, #27A9AC)" />
                <path d="M0 7.98062H1M15 7.98062H16" stroke="var(--stroke-1, #27A9AC)" />
                <path d="M0 7.98062H1M15 7.98062H16" stroke="var(--stroke-2, #27A9AC)" />
              </g>
            </g>
            <line id="Line 9" stroke="var(--stroke-0, white)" x1="11" x2="14" y1="0.5" y2="0.5" />
            <line id="Line 13" stroke="var(--stroke-0, white)" x1="11" x2="14" y1="4.79558" y2="4.79558" />
            <line id="Line 10" stroke="var(--stroke-0, white)" x1="13" x2="15" y1="1.57423" y2="1.57423" />
            <line id="Line 15" stroke="var(--stroke-0, white)" x1="10" x2="12" y1="1.57423" y2="1.57423" />
            <line id="Line 11" stroke="var(--stroke-0, white)" x1="13" x2="15" y1="3.7218" y2="3.7218" />
            <line id="Line 14" stroke="var(--stroke-0, white)" x1="10" x2="12" y1="3.7218" y2="3.7218" />
            <line id="Line 12" stroke="var(--stroke-0, white)" x1="14" x2="15" y1="2.64801" y2="2.64801" />
            <line id="Line 16" stroke="var(--stroke-0, white)" x1="10" x2="11" y1="2.64801" y2="2.64801" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[223px] top-[171.18px]">
      <Group6 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[214px] top-[159px]">
      <div className="absolute bg-[#f0f4ff] h-[49px] left-[214px] rounded-br-[12px] rounded-tl-[12px] rounded-tr-[12px] top-[159px] w-[472px]" />
      <div className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal h-[30px] leading-[normal] left-[246px] not-italic text-[12px] text-black top-[170px] w-[423px]">
        <p className="mb-0">{`신장병 관련 정보를 편리하게 제공하는 AI 챗봇 케어가이드입니다. `}</p>
        <p>프로필을 일반인, 신장병 환우, 연구자 중 선택하시고 대화해 보세요.</p>
      </div>
      <Group7 />
    </div>
  );
}

function Group57() {
  return (
    <div className="absolute contents left-[199px] top-[144px]">
      <div className="absolute bg-white h-[604px] left-[199px] rounded-[12px] top-[144px] w-[739px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-0 pointer-events-none rounded-[12px]" />
      </div>
      <Group32 />
      <Group10 />
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute contents left-[214px] top-[216px]">
      <div className="absolute bg-white h-[29px] left-[214px] rounded-[8px] top-[216px] w-[114px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium h-[12px] leading-[normal] left-[270.5px] not-italic text-[#1f1f1f] text-[10px] text-center top-[224px] translate-x-[-50%] w-[101.298px]">신장병 진단 등록하기</p>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents left-[214px] top-[216px]">
      <Group20 />
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute contents left-[337px] top-[216px]">
      <div className="absolute h-[29px] left-[337px] top-[216px] w-[127px]">
        <div className="absolute inset-[-1.72%_-0.39%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 128 30">
            <path d={svgPaths.p26528300} fill="var(--fill-0, white)" id="Rectangle 8" stroke="var(--stroke-0, #EBEBEB)" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium h-[12px] leading-[normal] left-[400.5px] not-italic text-[#1f1f1f] text-[10px] text-center top-[224px] translate-x-[-50%] w-[111px]">영양관리 목표 등록하기</p>
    </div>
  );
}

function Group37() {
  return (
    <div className="absolute contents left-[337px] top-[216px]">
      <Group22 />
    </div>
  );
}

function Group23() {
  return (
    <div className="absolute contents left-[207px] top-[672px]">
      <div className="absolute bg-white h-[68px] left-[207px] rounded-[8px] top-[672px] w-[725px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[216px] not-italic text-[#9c9c9c] text-[12px] top-[682px] w-[433px]">메시지를 입력하세요</p>
    </div>
  );
}

function Group25() {
  return (
    <div className="absolute contents left-[215px] top-[708px]">
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[251px] not-italic text-[#9c9c9c] text-[12px] top-[714px] w-[55px]">맞춤 정보:</p>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[306px] not-italic text-[#27a9ac] text-[12px] top-[714px] w-[61px]">신장병 환우</p>
      <div className="absolute h-[24px] left-[215px] top-[709px] w-[23px]" data-name="image 33">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[190.79%] left-[-18.55%] max-w-none top-[-45.39%] w-[1225.74%]" src={imgImage33} />
        </div>
      </div>
      <div className="absolute h-[26px] left-[244px] rounded-[4px] top-[708px] w-[129px]">
        <div aria-hidden="true" className="absolute border border-[#eeeff2] border-solid inset-0 pointer-events-none rounded-[4px]" />
      </div>
    </div>
  );
}

function Group27() {
  return (
    <div className="absolute contents left-[207px] top-[672px]">
      <Group23 />
      <Group25 />
    </div>
  );
}

function IconamoonSendFill1() {
  return (
    <div className="absolute left-[908px] size-[17px] top-[714px]" data-name="iconamoon:send-fill">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
        <g id="iconamoon:send-fill">
          <path clipRule="evenodd" d={svgPaths.p13ce6900} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group34() {
  return (
    <div className="absolute contents left-[904px] top-[711px]">
      <div className="absolute bg-gradient-to-b from-[#27a9ac] left-[904px] rounded-[8px] size-[24px] to-[#aa58a6] top-[711px]" />
      <IconamoonSendFill1 />
    </div>
  );
}

function Group35() {
  return (
    <div className="absolute contents left-[207px] top-[672px]">
      <Group27 />
      <Group34 />
    </div>
  );
}

function OcticonPerson() {
  return (
    <div className="absolute left-[29px] size-[24px] top-[675px]" data-name="octicon:person-24">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="octicon:person-24">
          <path d={svgPaths.p6366980} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group36() {
  return (
    <div className="absolute contents left-[29px] top-[673px]">
      <OcticonPerson />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[normal] left-[64px] not-italic text-[11px] text-black text-nowrap top-[673px] whitespace-pre">{`닉네임 | 100 포인트 `}</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[65px] not-italic text-[11px] text-black text-nowrap top-[689px] whitespace-pre">{`Free Plan `}</p>
    </div>
  );
}

function Group58() {
  return (
    <div className="absolute contents left-[27px] top-[673px]">
      <Group36 />
      <div className="absolute left-[27px] size-[28px] top-[674px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
          <circle cx="14" cy="14" id="Ellipse 4" r="13.5" stroke="var(--stroke-0, black)" />
        </svg>
      </div>
    </div>
  );
}

function Group33() {
  return (
    <div className="absolute contents left-[50px] top-[6.81px]">
      <div className="absolute h-[37.629px] left-[50px] top-[6.81px] w-[37.63px]" data-name="image 28">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage28} />
      </div>
      <p className="absolute bg-clip-text font-['Inter:Thin',sans-serif] font-thin h-[18.031px] leading-[20px] left-[82.14px] not-italic text-[20px] top-[20.93px] w-[33.71px]" style={{ WebkitTextFillColor: "transparent", backgroundImage: "url('data:image/svg+xml;utf8,<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' viewBox=\\\'0 0 33.71 18.031\\\' preserveAspectRatio=\\\'none\\\'><g transform=\\\'matrix(1.6855 0 0 0.90153 16.855 9.0153)\\\'><foreignObject x=\\\'-190\\\' y=\\\'-190\\\' width=\\\'380\\\' height=\\\'380\\\'><div xmlns=\\\'http://www.w3.org/1999/xhtml\\\' style=\\\'background-image: conic-gradient(from 90deg, rgba(75, 40, 74, 1) 0%, rgba(66, 72, 98, 1) 25%, rgba(57, 104, 123, 1) 50%, rgba(48, 137, 147, 1) 75%, rgba(39, 169, 172, 1) 100%); opacity:1; height: 100%; width: 100%;\\\'></div></foreignObject></g></svg>')" }}>
        are
      </p>
    </div>
  );
}

function Group53() {
  return (
    <div className="absolute contents left-[50px] top-[6.81px]">
      <Group33 />
      <p className="absolute bg-clip-text font-['Inter:Thin',sans-serif] font-thin h-[18.031px] leading-[20px] left-[108.8px] not-italic text-[0px] top-[18.57px] w-[68.204px]" style={{ WebkitTextFillColor: "transparent", backgroundImage: "url('data:image/svg+xml;utf8,<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' viewBox=\\\'0 0 68.204 18.031\\\' preserveAspectRatio=\\\'none\\\'><g transform=\\\'matrix(3.4102 0 0 0.90153 34.102 9.0153)\\\'><foreignObject x=\\\'-190\\\' y=\\\'-190\\\' width=\\\'380\\\' height=\\\'380\\\'><div xmlns=\\\'http://www.w3.org/1999/xhtml\\\' style=\\\'background-image: conic-gradient(from 90deg, rgba(75, 40, 74, 1) 0%, rgba(66, 72, 98, 1) 25%, rgba(57, 104, 123, 1) 50%, rgba(48, 137, 147, 1) 75%, rgba(39, 169, 172, 1) 100%); opacity:1; height: 100%; width: 100%;\\\'></div></foreignObject></g></svg>')" }}>
        <span className="text-[32px]">P</span>
        <span className="text-[20px]">lus</span>
      </p>
    </div>
  );
}

export default function DesktopChatMedical() {
  return (
    <div className="bg-white relative size-full" data-name="Desktop_chat_medical">
      <div className="absolute h-[764.98px] left-0 top-[48px] w-[967px]" data-name="image 8">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage8} />
      </div>
      <div className="absolute bg-white h-[589px] left-[204px] rounded-[8px] top-[150px] w-[736px]">
        <div aria-hidden="true" className="absolute border border-[#e0e0e0] border-solid inset-0 pointer-events-none rounded-[8px]" />
      </div>
      <Group5 />
      <div className="absolute bg-[#f1feff] h-[28px] left-[712px] top-[775px] w-[241px]" />
      <Group28 />
      <Group51 />
      <div className="absolute bg-[#ebf7f7] h-[28px] left-[22px] rounded-[8px] top-[68px] w-[158px]" />
      <Group50 />
      <Group19 />
      <Group57 />
      <Group13 />
      <Group37 />
      <div className="absolute bg-gradient-to-b from-[#f6feff] h-[226px] left-[14px] to-[#f1fdff] top-[522px] w-[177px]" />
      <Group35 />
      <Group58 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[normal] left-[82px] not-italic text-[11px] text-black text-nowrap top-[721px] whitespace-pre">업그레이드</p>
      <div className="absolute h-[32px] left-[23px] rounded-[12px] top-[712px] w-[168px]">
        <div aria-hidden="true" className="absolute border border-black border-solid inset-0 pointer-events-none rounded-[12px]" />
      </div>
      <Group53 />
    </div>
  );
}