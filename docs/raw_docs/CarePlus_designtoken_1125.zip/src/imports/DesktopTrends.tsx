import svgPaths from "./svg-zg0detnli9";
import imgImageWithFallback from "figma:asset/d7e1e0454380300cf13574ce506f3fd2ee851220.png";
import imgImageWithFallback1 from "figma:asset/c98a6fdc8c03f18221ec677c6bf7c2c07a92f88c.png";
import img1 from "figma:asset/d47d8e35234fb905b955d7974c74d1f72bab5e5f.png";
import imgImageWithFallback2 from "figma:asset/1c515157c0bcac074f0275c981b23397827a5cfe.png";
import imgImage28 from "figma:asset/94edcf03a48343a4968b0f15d76b0b3fe1300c2d.png";

function Container() {
  return <div className="absolute bg-[#9f7aea] h-[3px] left-0 top-[31.5px] w-[41.406px]" data-name="Container" />;
}

function Button() {
  return (
    <div className="absolute h-[34.5px] left-0 top-0 w-[41.406px]" data-name="Button">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[22.5px] left-[21px] not-italic text-[#00c8b4] text-[15px] text-center text-nowrap top-0 translate-x-[-50%] whitespace-pre">새소식</p>
      <Container />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute box-border content-stretch flex h-[34.5px] items-start left-[65.41px] pb-[12px] pt-0 px-0 top-0 w-[55.203px]" data-name="Button">
      <p className="font-['Noto_Sans_KR:Regular',sans-serif] leading-[22.5px] not-italic relative shrink-0 text-[15px] text-center text-gray-600 text-nowrap whitespace-pre">대시보드</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute h-[34.5px] left-0 top-0 w-[1104px]" data-name="Container">
      <Button />
      <Button1 />
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute h-[35.5px] left-[24px] top-[24px] w-[1104px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <Container1 />
    </div>
  );
}

function Heading() {
  return (
    <div className="absolute h-[20.523px] left-[16px] overflow-clip top-[16px] w-[896px]" data-name="Heading 4">
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[20.533px] left-0 not-italic text-[14.667px] text-black text-nowrap top-[-0.5px] whitespace-pre">{`2025 미국신장학회 신장주간서 FINE-ONE 3상 연구 결과' 발표`}</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="absolute h-[37.328px] left-[16.5px] overflow-clip top-[55.5px] w-[896px]" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[18.667px] left-0 not-italic text-[#272727] text-[13.333px] top-[-0.5px] w-[895px]">FINE-ONE 연구 결과, 1형 당뇨병 동반 만성 신장병 성인 환자를 대상으로 표준치료에 피네레논을 추가 투여 시 위약 대비 베이스라인 이후 6개월 간 요-알부민-크레아티닌 비율(UACR)의 유의한 감소 효과를 확인했다. 전 세계 만성신장병(Chronic Kidney Disease, CKD) 성인환자가 8억 명으로 30년새 두 배 이상 증가했다는 분석...</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="absolute h-[12px] left-0 top-[4px] w-[78.719px]" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[12px] left-0 not-italic text-[#777777] text-[9px] top-[-0.5px] w-[79px]">메디컬헤럴드 | 2일전</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[876px] size-[20px] top-0" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pc3ae900} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.39167" />
        </g>
      </svg>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute h-[20px] left-[16px] top-[111px] w-[896px]" data-name="Container">
      <Paragraph1 />
      <Icon />
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute h-[141px] left-[128px] top-0 w-[928px]" data-name="Container">
      <Heading />
      <Paragraph />
      <Container3 />
    </div>
  );
}

function ImageWithFallback() {
  return (
    <div className="absolute h-[145px] left-[0.5px] top-[0.5px] w-[128px]" data-name="ImageWithFallback">
      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImageWithFallback} />
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute h-[141px] left-0 top-0 w-[128px]" data-name="Container">
      <ImageWithFallback />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute bg-white h-[141px] left-[24px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[16px] w-[1056px]" data-name="Container">
      <Container4 />
      <Container5 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[20.523px] relative shrink-0 w-[896px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20.523px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[20.533px] left-0 not-italic text-[14.667px] text-black text-nowrap top-[-0.5px] whitespace-pre">전 세계 CKD 성인환자 8억 명</p>
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[18.664px] relative shrink-0 w-[896px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18.664px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[18.667px] left-0 not-italic text-[#272727] text-[13.333px] text-nowrap top-[-0.5px] whitespace-pre">전 세계 만성신장병(Chronic Kidney Disease, CKD) 성인환자가 8억 명으로 30년새 두 배 이상 증가했다는 분석 결과가 나왔다.</p>
      </div>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[12px] relative shrink-0 w-[78.719px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[12px] relative w-[78.719px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[12px] left-0 not-italic text-[#777777] text-[9px] top-[-0.5px] w-[79px]">메디컬트리뷴 | 3일전</p>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pc3ae900} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.39167" />
        </g>
      </svg>
    </div>
  );
}

function Container7() {
  return (
    <div className="h-[20px] relative shrink-0 w-[896px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[20px] items-center justify-between relative w-[896px]">
        <Paragraph3 />
        <Icon1 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute box-border content-stretch flex flex-col h-[128px] items-start justify-between left-[128px] pb-0 pl-[16px] pr-0 pt-[16px] top-0 w-[928px]" data-name="Container">
      <Heading1 />
      <Paragraph2 />
      <Container7 />
    </div>
  );
}

function ImageWithFallback1() {
  return (
    <div className="absolute h-[148px] left-0 overflow-clip top-0 w-[128px]" data-name="ImageWithFallback">
      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImageWithFallback1} />
      <div className="absolute h-[238px] left-[-155px] top-[-106px] w-[317px]" data-name="성 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img1} />
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute h-[141px] left-[0.5px] top-[0.5px] w-[128px]" data-name="Container">
      <ImageWithFallback1 />
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute bg-white h-[141px] left-[24px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[173px] w-[1056px]" data-name="Container">
      <Container8 />
      <Container9 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[20.523px] relative shrink-0 w-[896px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20.523px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[20.533px] left-0 not-italic text-[14.667px] text-black text-nowrap top-[-0.5px] whitespace-pre">전 세계 CKD 성인환자 8억 명</p>
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[18.664px] relative shrink-0 w-[896px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18.664px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[18.667px] left-0 not-italic text-[#272727] text-[13.333px] text-nowrap top-[-0.5px] whitespace-pre">전 세계 만성신장병(Chronic Kidney Disease, CKD) 성인환자가 8억 명으로 30년새 두 배 이상 증가했다는 분석 결과가 나왔다.</p>
      </div>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[12px] relative shrink-0 w-[78.719px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[12px] relative w-[78.719px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[12px] left-0 not-italic text-[#777777] text-[9px] top-[-0.5px] w-[79px]">메디컬트리뷴 | 3일전</p>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pc3ae900} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.39167" />
        </g>
      </svg>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[20px] relative shrink-0 w-[896px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[20px] items-center justify-between relative w-[896px]">
        <Paragraph5 />
        <Icon2 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute box-border content-stretch flex flex-col h-[128px] items-start justify-between left-[128px] pb-0 pl-[16px] pr-0 pt-[16px] top-0 w-[928px]" data-name="Container">
      <Heading2 />
      <Paragraph4 />
      <Container11 />
    </div>
  );
}

function ImageWithFallback2() {
  return (
    <div className="absolute h-[148px] left-0 top-0 w-[128px]" data-name="ImageWithFallback">
      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImageWithFallback1} />
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[141px] left-[0.5px] top-[0.5px] w-[128px]" data-name="Container">
      <ImageWithFallback2 />
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute bg-white h-[141px] left-[24px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[330px] w-[1056px]" data-name="Container">
      <Container12 />
      <Container13 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[20.523px] relative shrink-0 w-[896px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20.523px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[20.533px] left-0 not-italic text-[14.667px] text-black text-nowrap top-[-0.5px] whitespace-pre">만성신장병 급여확대 포시가 제네릭은 되고, 자디앙 안된 이유</p>
      </div>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[37.328px] relative shrink-0 w-[896px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[37.328px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[18.667px] left-0 not-italic text-[#272727] text-[13.333px] top-[-0.5px] w-[895px]">FINE-ONE 연구 결과, 1형 당뇨병 동반 만성 신장병 성인 환자를 대상으로 표준치료에 피네레논을 추가 투여 시 위약 대비 베이스라인 이후 6개월 간 요-알부민-크레아티닌 비율(UACR)의 유의한 감소 효과를 확인했다...</p>
      </div>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[12px] relative shrink-0 w-[78.719px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[12px] relative w-[78.719px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[12px] left-0 not-italic text-[#777777] text-[9px] top-[-0.5px] w-[79px]">메디컬헤럴드 | 2일전</p>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pc3ae900} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.39167" />
        </g>
      </svg>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[20px] relative shrink-0 w-[896px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[20px] items-center justify-between relative w-[896px]">
        <Paragraph7 />
        <Icon3 />
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute box-border content-stretch flex flex-col h-[128px] items-start justify-between left-[128px] pb-0 pl-[16px] pr-0 pt-[16px] top-0 w-[928px]" data-name="Container">
      <Heading3 />
      <Paragraph6 />
      <Container15 />
    </div>
  );
}

function ImageWithFallback3() {
  return (
    <div className="absolute h-[146px] left-[0.5px] top-[0.5px] w-[128px]" data-name="ImageWithFallback">
      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImageWithFallback2} />
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute left-0 size-[128px] top-0" data-name="Container">
      <ImageWithFallback3 />
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute bg-white h-[142px] left-[24px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[487px] w-[1056px]" data-name="Container">
      <Container16 />
      <Container17 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="h-[20.523px] relative shrink-0 w-[896px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[20.523px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[20.533px] left-0 not-italic text-[14.667px] text-black text-nowrap top-[-0.5px] whitespace-pre">{`2025 미국신장학회 신장주간서 FINE-ONE 3상 연구 결과' 발표`}</p>
      </div>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[37.328px] relative shrink-0 w-[896px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[37.328px] overflow-clip relative rounded-[inherit] w-[896px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[18.667px] left-0 not-italic text-[#272727] text-[13.333px] top-[-0.5px] w-[895px]">FINE-ONE 연구 결과, 1형 당뇨병 동반 만성 신장병 성인 환자를 대상으로 표준치료에 피네레논을 추가 투여 시 위약 대비 베이스라인 이후 6개월 간 요-알부민-크레아티닌 비율(UACR)의 유의한 감소 효과를 확인했다...</p>
      </div>
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="h-[12px] relative shrink-0 w-[78.719px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[12px] relative w-[78.719px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[12px] left-0 not-italic text-[#777777] text-[9px] top-[-0.5px] w-[79px]">메디컬헤럴드 | 2일전</p>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pc3ae900} id="Vector" stroke="var(--stroke-0, #CCCCCC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.39167" />
        </g>
      </svg>
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[20px] relative shrink-0 w-[896px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[20px] items-center justify-between relative w-[896px]">
        <Paragraph9 />
        <Icon4 />
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute box-border content-stretch flex flex-col h-[128px] items-start justify-between left-[128px] pb-0 pl-[16px] pr-0 pt-[16px] top-0 w-[928px]" data-name="Container">
      <Heading4 />
      <Paragraph8 />
      <Container19 />
    </div>
  );
}

function ImageWithFallback4() {
  return (
    <div className="absolute h-[146px] left-[0.5px] top-[0.5px] w-[128px]" data-name="ImageWithFallback">
      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImageWithFallback} />
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute left-0 size-[128px] top-0" data-name="Container">
      <ImageWithFallback4 />
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute bg-white h-[141px] left-[24px] overflow-clip rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] top-[645px] w-[1056px]" data-name="Container">
      <Container20 />
      <Container21 />
    </div>
  );
}

function Container23() {
  return (
    <div className="absolute bg-white h-[592px] left-[24px] top-[67.5px] w-[1104px]" data-name="Container">
      <Container6 />
      <Container10 />
      <Container14 />
      <Container18 />
      <Container22 />
    </div>
  );
}

function Container24() {
  return (
    <div className="h-[788.289px] relative shrink-0 w-full" data-name="Container">
      <Container2 />
      <Container23 />
    </div>
  );
}

function TrendsPage() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col h-[883px] items-start left-[280px] overflow-clip px-[23.5px] py-0 top-[64px] w-[1199px]" data-name="TrendsPage">
      <Container24 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute h-[6px] left-[34px] top-[31.59px] w-[20px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-33.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 8">
          <g id="Group 42">
            <line id="Line 22" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="1" y2="1" />
            <line id="Line 23" stroke="var(--stroke-0, #3D3D3D)" strokeWidth="2" x2="20" y1="7" y2="7" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="absolute bg-white h-[64px] left-0 top-0 w-[1479px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <Group />
    </div>
  );
}

function ChatbotIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="ChatbotIcon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="ChatbotIcon">
          <path d={svgPaths.p28e5c180} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.14286" />
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[24px] relative shrink-0 w-[44.344px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[44.344px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[22.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">AI챗봇</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <ChatbotIcon />
          <Text />
        </div>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3a2bba00} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p7df6000} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p30991400} id="Vector_3" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M15.8333 4.16667L10 10" id="Vector_4" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">식단케어</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon5 />
          <Text1 />
        </div>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3ace1680} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p105cfc80} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p312978e0} id="Vector_3" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M3.33333 18.3333H16.6667" id="Vector_4" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p1356a280} id="Vector_5" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p18544000} id="Vector_6" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">퀴즈미션</p>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon6 />
          <Text2 />
        </div>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p25397b80} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p166b7100} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2241fff0} id="Vector_3" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2c4f400} id="Vector_4" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">커뮤니티</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon7 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3ac0b600} id="Vector" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p3c797180} id="Vector_2" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[24px] relative shrink-0 w-[44.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[44.164px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[22.5px] not-italic text-[#00c8b4] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">트렌드</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon8 />
          <Text4 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[279px]" data-name="Navigation">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-full items-start overflow-clip pb-0 pt-[16px] px-[16px] relative rounded-[inherit] w-[279px]">
        <Button2 />
        <Button3 />
        <Button4 />
        <Button5 />
        <Button6 />
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p2026e800} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p32ab0300} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[24px] relative shrink-0 w-[73.602px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[73.602px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[37px] not-italic text-[#666666] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">마이페이지</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon9 />
          <Text5 />
        </div>
      </div>
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="h-[17.594px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[17.6px] left-0 not-italic text-[11px] text-gray-400 text-nowrap top-[-0.5px] whitespace-pre">© 2025 CareGuide</p>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[15px] relative shrink-0 w-[27.602px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[15px] items-start relative w-[27.602px]">
        <p className="[text-underline-position:from-font] decoration-solid font-['Noto_Sans_KR:Regular',sans-serif] leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-gray-400 text-nowrap underline whitespace-pre">도움말</p>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[15px] relative shrink-0 w-[18.406px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[15px] items-start relative w-[18.406px]">
        <p className="[text-underline-position:from-font] decoration-solid font-['Noto_Sans_KR:Regular',sans-serif] leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-gray-400 text-nowrap underline whitespace-pre">약관</p>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[15px] relative shrink-0 w-[76.406px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[15px] items-start relative w-[76.406px]">
        <p className="[text-underline-position:from-font] decoration-solid font-['Noto_Sans_KR:Regular',sans-serif] leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-gray-400 text-nowrap underline whitespace-pre">개인정보 처리방침</p>
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="content-stretch flex gap-[12px] h-[15px] items-start relative shrink-0 w-full" data-name="Container">
      <Button8 />
      <Button9 />
      <Button10 />
    </div>
  );
}

function Container26() {
  return (
    <div className="box-border content-stretch flex flex-col gap-[8px] h-[56.594px] items-start pb-0 pt-[16px] px-0 relative shrink-0 w-full" data-name="Container">
      <Paragraph10 />
      <Container25 />
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[167px] relative shrink-0 w-[279px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1px_0px_0px] border-gray-100 border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[16px] h-[167px] items-start pb-0 pt-[17px] px-[16px] relative w-[279px]">
        <Button7 />
        <Container26 />
      </div>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col h-[884px] items-start left-0 pl-0 pr-px py-0 top-[64px] w-[280px]" data-name="Sidebar">
      <div aria-hidden="true" className="absolute border-[0px_1px_0px_0px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <Navigation />
      <Container27 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[70px] top-[19px]">
      <div className="absolute h-[37.629px] left-[70px] top-[19px] w-[37.63px]" data-name="image 28">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage28} />
      </div>
      <p className="absolute bg-clip-text font-['Inter:Thin',sans-serif] font-thin h-[18.031px] leading-[20px] left-[102.14px] not-italic text-[20px] top-[33.11px] w-[33.71px]" style={{ WebkitTextFillColor: "transparent", backgroundImage: "url('data:image/svg+xml;utf8,<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' viewBox=\\\'0 0 33.71 18.031\\\' preserveAspectRatio=\\\'none\\\'><g transform=\\\'matrix(1.6855 0 0 0.90153 16.855 9.0153)\\\'><foreignObject x=\\\'-190\\\' y=\\\'-190\\\' width=\\\'380\\\' height=\\\'380\\\'><div xmlns=\\\'http://www.w3.org/1999/xhtml\\\' style=\\\'background-image: conic-gradient(from 90deg, rgba(75, 40, 74, 1) 0%, rgba(66, 72, 98, 1) 25%, rgba(57, 104, 123, 1) 50%, rgba(48, 137, 147, 1) 75%, rgba(39, 169, 172, 1) 100%); opacity:1; height: 100%; width: 100%;\\\'></div></foreignObject></g></svg>')" }}>
        are
      </p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[70px] top-[19px]">
      <Group1 />
      <p className="absolute bg-clip-text font-['Inter:Thin',sans-serif] font-thin h-[18.031px] leading-[20px] left-[128.8px] not-italic text-[0px] top-[30.76px] w-[68.204px]" style={{ WebkitTextFillColor: "transparent", backgroundImage: "url('data:image/svg+xml;utf8,<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' viewBox=\\\'0 0 68.204 18.031\\\' preserveAspectRatio=\\\'none\\\'><g transform=\\\'matrix(3.4102 0 0 0.90153 34.102 9.0153)\\\'><foreignObject x=\\\'-190\\\' y=\\\'-190\\\' width=\\\'380\\\' height=\\\'380\\\'><div xmlns=\\\'http://www.w3.org/1999/xhtml\\\' style=\\\'background-image: conic-gradient(from 90deg, rgba(75, 40, 74, 1) 0%, rgba(66, 72, 98, 1) 25%, rgba(57, 104, 123, 1) 50%, rgba(48, 137, 147, 1) 75%, rgba(39, 169, 172, 1) 100%); opacity:1; height: 100%; width: 100%;\\\'></div></foreignObject></g></svg>')" }}>
        <span className="text-[32px]">P</span>
        <span className="text-[20px]">lus</span>
      </p>
    </div>
  );
}

export default function DesktopTrends() {
  return (
    <div className="bg-white relative size-full" data-name="desktop_trends">
      <TrendsPage />
      <Header />
      <Sidebar />
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[31.2px] left-[728px] not-italic text-[20px] text-gray-800 text-nowrap top-[15px] whitespace-pre">트렌드</p>
      <div className="absolute h-0 left-0 top-[861px] w-[279px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 279 1">
            <line id="Line 39" stroke="var(--stroke-0, #E5E7EB)" x2="279" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
      <Group2 />
    </div>
  );
}