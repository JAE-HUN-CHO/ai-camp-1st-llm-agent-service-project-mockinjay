import svgPaths from "./svg-8c927f3vp3";

function Icon() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d="M8.25 1.5V3" id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M3.75 1.5V3" id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p25290e80} id="Vector_3" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p17351d80} id="Vector_4" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p39b4d600} id="Vector_5" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[51.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[19.5px] relative w-[51.484px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[19.5px] left-[26.5px] not-italic text-[#666666] text-[13px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">의료 복지</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-white box-border content-stretch flex gap-[8px] h-[43.5px] items-center justify-center left-0 pl-[2px] pr-[2.008px] py-[2px] rounded-[16.4px] top-0 w-[378.664px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-2 border-gray-200 border-solid inset-0 pointer-events-none rounded-[16.4px]" />
      <Icon />
      <Text />
    </div>
  );
}

function Text1() {
  return <div className="absolute h-[19.5px] left-[163.59px] top-[12px] w-[51.484px]" data-name="Text" />;
}

function Icon1() {
  return (
    <div className="absolute left-[-30px] size-[18px] top-[0.75px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d={svgPaths.p14aa8000} id="Vector" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M5.25 1.5V16.5" id="Vector_2" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p23207a00} id="Vector_3" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[-30px] top-[0.5px]">
      <Icon1 />
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[19.5px] left-[22.5px] not-italic text-[#00c8b4] text-[13px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">식이 영양</p>
    </div>
  );
}

function Text2() {
  return (
    <div className="absolute h-[19.5px] left-[185px] top-[12px] w-[51.484px]" data-name="Text">
      <Group4 />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-white h-[43.5px] left-[-0.16px] rounded-[16.4px] top-0 w-[378.664px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-2 border-[#00c8b4] border-solid inset-0 pointer-events-none rounded-[16.4px]" />
      <Text1 />
      <Text2 />
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute h-[43.5px] left-[386.66px] rounded-[16.4px] top-0 w-[378.664px]" data-name="Button" style={{ backgroundImage: "linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%), linear-gradient(173.447deg, rgb(0, 200, 180) 0%, rgb(159, 122, 234) 100%), linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%)" }}>
      <div aria-hidden="true" className="absolute border-2 border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[16.4px]" />
      <Button1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d={svgPaths.p278d4f80} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p11648c20} id="Vector_2" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M7.5 6.75H6" id="Vector_3" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M12 9.75H6" id="Vector_4" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M12 12.75H6" id="Vector_5" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[51.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[19.5px] relative w-[51.484px]">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[19.5px] left-[26.5px] not-italic text-[#666666] text-[13px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">연구 논문</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-white box-border content-stretch flex gap-[8px] h-[43.5px] items-center justify-center left-[773.33px] pl-[2px] pr-[2.008px] py-[2px] rounded-[16.4px] top-0 w-[378.664px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-2 border-gray-200 border-solid inset-0 pointer-events-none rounded-[16.4px]" />
      <Icon2 />
      <Text3 />
    </div>
  );
}

function Container() {
  return (
    <div className="h-[43.5px] relative shrink-0 w-full" data-name="Container">
      <Button />
      <Button2 />
      <Button3 />
    </div>
  );
}

function Container1() {
  return (
    <div className="bg-white h-[68.5px] relative shrink-0 w-[1209px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col h-[68.5px] items-start pb-px pt-[12px] px-[28.5px] relative w-[1209px]">
        <Container />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[4px] size-[16px] top-[4px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p140b0380} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M4.66667 1.33333V14.6667" id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3fcd0100} id="Vector_3" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute bg-gray-100 left-0 rounded-[1.67772e+07px] size-[24px] top-0" data-name="Container">
      <Icon3 />
    </div>
  );
}

function Text4() {
  return (
    <div className="absolute h-[16px] left-[32px] top-[4px] w-[72.703px]" data-name="Text">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[16px] left-0 not-italic text-[#6a7282] text-[12px] text-nowrap top-0 whitespace-pre">CareGuide AI</p>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute h-[24px] left-0 top-0 w-[506.961px]" data-name="Container">
      <Container2 />
      <Text4 />
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute bg-[#f0f4ff] h-[43.195px] left-[8px] rounded-bl-[12px] rounded-br-[12px] rounded-tr-[12px] top-[28px] w-[498.961px]" data-name="Container">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[19.2px] left-[16px] not-italic text-[12px] text-black text-nowrap top-[11.5px] whitespace-pre">안녕하세요! 신장병의 식이 영양 정보를 알려드리는 케어가이드 챗봇입니다. 무엇이든 물어보세요.</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute h-[71.195px] left-[28.5px] top-[24px] w-[506.961px]" data-name="Container">
      <Container3 />
      <Container4 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[37px] top-[103.5px]">
      <div className="absolute bg-white h-[29px] left-[37px] rounded-[8px] top-[103.5px] w-[146px]">
        <div aria-hidden="true" className="absolute border border-[#ebebeb] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[109.17px] not-italic text-[#1f1f1f] text-[10px] text-center top-[111.5px] translate-x-[-50%] w-[116.544px]">저칼륨 음식 재료 알려줘</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[37px] top-[103.5px]">
      <Group />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[195px] top-[103.5px]">
      <div className="absolute h-[29px] left-[195px] top-[103.5px] w-[200px]">
        <div className="absolute inset-[-1.72%_-0.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 201 30">
            <path d={svgPaths.p32b0d450} fill="var(--fill-0, white)" id="Rectangle 8" stroke="var(--stroke-0, #EBEBEB)" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="absolute font-['Inter:Medium','Noto_Sans_KR:Medium',sans-serif] font-medium leading-[normal] left-[297.5px] not-italic text-[#1f1f1f] text-[10px] text-center top-[111.5px] translate-x-[-50%] w-[163px]">신장병 환자를 위한 김장 레시피 알려줘</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[195px] top-[103.5px]">
      <Group1 />
    </div>
  );
}

function Container6() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-[1209px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full overflow-clip relative rounded-[inherit] w-[1209px]">
        <Container5 />
        <Group2 />
        <Group3 />
      </div>
    </div>
  );
}

function ChatPage() {
  return (
    <div className="bg-white content-stretch flex flex-col h-[867px] items-start relative shrink-0 w-full" data-name="ChatPage">
      <Container1 />
      <Container6 />
    </div>
  );
}

function AppContent() {
  return (
    <div className="absolute bg-gray-50 box-border content-stretch flex flex-col h-[931px] items-start left-0 pb-0 pl-[280px] pr-0 pt-[64px] top-0 w-[1489px]" data-name="AppContent">
      <ChatPage />
    </div>
  );
}

function Text5() {
  return (
    <div className="absolute h-[21px] left-0 top-[-20000px] w-[7.773px]" data-name="Text">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[21px] left-0 not-italic text-[14px] text-gray-800 text-nowrap top-[-0.5px] whitespace-pre">0</p>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1cec7ff0} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p38772900} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p27fa8ca0} id="Vector_3" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 rounded-[1.67772e+07px] size-[32px] top-[4px]" data-name="Button">
      <Icon4 />
    </div>
  );
}

function TextInput() {
  return (
    <div className="absolute box-border content-stretch flex h-[40px] items-center left-[40px] overflow-clip p-[8px] top-0 w-[1054px]" data-name="Text Input">
      <p className="font-['Noto_Sans_KR:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[14px] text-[rgba(30,41,57,0.5)] text-nowrap whitespace-pre">메시지를 입력하세요</p>
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_87_4658)" id="Icon">
          <path d={svgPaths.p3fccf600} id="Vector" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p3bf11880} id="Vector_2" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_87_4658">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-gray-100 content-stretch flex items-center justify-center left-[1102px] rounded-[1.67772e+07px] size-[32px] top-[4px]" data-name="Button">
      <Icon5 />
    </div>
  );
}

function Form() {
  return (
    <div className="h-[40px] relative shrink-0 w-full" data-name="Form">
      <Button4 />
      <TextInput />
      <Button5 />
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-0 top-[4px] w-[46.633px]" data-name="Text">
      <p className="font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] not-italic relative shrink-0 text-[11px] text-gray-500 text-nowrap whitespace-pre">맞춤 정보:</p>
    </div>
  );
}

function Option() {
  return (
    <div className="absolute left-[-380.13px] size-0 top-[-813.5px]" data-name="Option">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] left-0 not-italic text-[#00c8b4] text-[11px] top-0 w-0">신장병 환우</p>
    </div>
  );
}

function Option1() {
  return (
    <div className="absolute left-[-380.13px] size-0 top-[-813.5px]" data-name="Option">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] left-0 not-italic text-[#00c8b4] text-[11px] top-0 w-0">일반인(간병인)</p>
    </div>
  );
}

function Option2() {
  return (
    <div className="absolute left-[-380.13px] size-0 top-[-813.5px]" data-name="Option">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] left-0 not-italic text-[#00c8b4] text-[11px] top-0 w-0">연구자</p>
    </div>
  );
}

function Dropdown() {
  return (
    <div className="absolute h-[20.5px] left-0 rounded-[4px] top-[4px] w-[89px]" data-name="Dropdown">
      <Option />
      <Option1 />
      <Option2 />
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] left-[5.87px] not-italic text-[#00c8b4] text-[11px] text-nowrap top-[0.5px] whitespace-pre">신장병 환우</p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[77px] size-[12px] top-[6.25px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M3 4.5L6 7.5L9 4.5" id="Vector" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute h-[24.5px] left-[54.63px] top-0 w-[89px]" data-name="Container">
      <Dropdown />
      <Icon6 />
    </div>
  );
}

function Container8() {
  return (
    <div className="h-[24.5px] relative shrink-0 w-[143.633px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24.5px] relative w-[143.633px]">
        <Text6 />
        <Container7 />
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[33.5px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1px_0px_0px] border-gray-100 border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex h-[33.5px] items-center justify-between pb-0 pl-[8px] pr-[982.367px] pt-px relative w-full">
          <Container8 />
        </div>
      </div>
    </div>
  );
}

function ChatPage1() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col gap-[8px] h-[99.5px] items-start left-[308.5px] pb-px pt-[9px] px-[9px] rounded-[16px] top-[799.5px] w-[1152px]" data-name="ChatPage">
      <div aria-hidden="true" className="absolute border border-[#e0e0e0] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Form />
      <Container9 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p3f86cd40} fill="var(--fill-0, white)" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container10() {
  return (
    <div className="relative rounded-[1.67772e+07px] shrink-0 size-[43.195px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex items-center justify-center pl-0 pr-[0.008px] py-0 relative size-[43.195px]">
        <Icon7 />
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="basis-0 grow h-[32px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[32px] relative w-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[32px] left-0 not-italic text-[24px] text-gray-800 text-nowrap top-[-1px] whitespace-pre">CarePlus</p>
      </div>
    </div>
  );
}

function Logo() {
  return (
    <div className="content-stretch flex gap-[8px] h-[43.195px] items-center relative shrink-0 w-full" data-name="Logo">
      <Container10 />
      <Text7 />
    </div>
  );
}

function Link() {
  return (
    <div className="h-[43.195px] relative shrink-0 w-[155.492px]" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col h-[43.195px] items-start relative w-[155.492px]">
        <Logo />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="absolute bg-white box-border content-stretch flex h-[64px] items-center justify-between left-0 pb-px pl-[24px] pr-[1309.51px] pt-0 top-[5px] w-[1489px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <Link />
    </div>
  );
}

function ChatbotIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="ChatbotIcon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="ChatbotIcon">
          <path d={svgPaths.p28e5c180} id="Vector" stroke="var(--stroke-0, #00C8B4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.14286" />
        </g>
      </svg>
    </div>
  );
}

function Text8() {
  return (
    <div className="h-[24px] relative shrink-0 w-[44.344px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[44.344px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[22.5px] not-italic text-[#00c8b4] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">AI챗봇</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <ChatbotIcon />
          <Text8 />
        </div>
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3a2bba00} id="Vector" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p7df6000} id="Vector_2" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p30991400} id="Vector_3" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M15.8333 4.16667L10 10" id="Vector_4" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text9() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#999999] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">식단케어</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon8 />
          <Text9 />
        </div>
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3ace1680} id="Vector" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p105cfc80} id="Vector_2" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p312978e0} id="Vector_3" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M3.33333 18.3333H16.6667" id="Vector_4" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p1356a280} id="Vector_5" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p18544000} id="Vector_6" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text10() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#999999] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">퀴즈미션</p>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon9 />
          <Text10 />
        </div>
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p25397b80} id="Vector" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p166b7100} id="Vector_2" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2241fff0} id="Vector_3" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2c4f400} id="Vector_4" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="h-[24px] relative shrink-0 w-[58.883px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[58.883px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[29.5px] not-italic text-[#999999] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">커뮤니티</p>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon10 />
          <Text11 />
        </div>
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3ac0b600} id="Vector" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p3c797180} id="Vector_2" stroke="var(--stroke-0, #999999)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text12() {
  return (
    <div className="h-[24px] relative shrink-0 w-[44.164px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[24px] relative w-[44.164px]">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[24px] left-[22.5px] not-italic text-[#999999] text-[16px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">트렌드</p>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[48px] relative rounded-[16.4px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[12px] h-[48px] items-center pl-[16px] pr-0 py-0 relative w-full">
          <Icon11 />
          <Text12 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="h-[678px] relative shrink-0 w-[279px]" data-name="Navigation">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-[678px] items-start overflow-clip pb-0 pt-[16px] px-[16px] relative rounded-[inherit] w-[279px]">
        <Button6 />
        <Button7 />
        <Button8 />
        <Button9 />
        <Button10 />
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="[grid-area:1_/_1] place-self-stretch relative rounded-[10px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e0e0e0] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex items-start px-[17px] py-[9px] relative size-full">
          <p className="basis-0 font-['Noto_Sans_KR:Medium',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[#666666] text-[14px] text-center">로그인</p>
        </div>
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="[grid-area:1_/_2] bg-[#00c9b7] place-self-stretch relative rounded-[10px] shrink-0" data-name="Button">
      <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] leading-[20px] left-[59.98px] not-italic text-[14px] text-center text-nowrap text-white top-[9px] translate-x-[-50%] whitespace-pre">회원가입</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="gap-[8px] grid grid-cols-[repeat(2,_minmax(0px,_1fr))] grid-rows-[repeat(1,_minmax(0px,_1fr))] h-[38px] relative shrink-0 w-full" data-name="Container">
      <Button11 />
      <Button12 />
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.pa1c60e0} id="Vector" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p351ec080} id="Vector_2" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Text13() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[20.242px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[16.5px] items-start relative w-[20.242px]">
        <p className="font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] not-italic relative shrink-0 text-[11px] text-center text-gray-400 text-nowrap whitespace-pre">알림</p>
      </div>
    </div>
  );
}

function Button13() {
  return (
    <div className="[grid-area:1_/_1] content-stretch flex gap-[8px] items-center place-self-stretch relative shrink-0" data-name="Button">
      <Icon12 />
      <Text13 />
    </div>
  );
}

function Icon13() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_87_4727)" id="Icon">
          <path d={svgPaths.p3e7757b0} id="Vector" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p442f010} id="Vector_2" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6 8.5H6.005" id="Vector_3" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_87_4727">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text14() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[40.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[16.5px] items-start relative w-[40.484px]">
        <p className="font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] not-italic relative shrink-0 text-[11px] text-center text-gray-400 text-nowrap whitespace-pre">고객지원</p>
      </div>
    </div>
  );
}

function Button14() {
  return (
    <div className="[grid-area:1_/_2] content-stretch flex gap-[8px] items-center place-self-stretch relative shrink-0" data-name="Button">
      <Icon13 />
      <Text14 />
    </div>
  );
}

function Icon14() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.pbd88400} id="Vector" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p26672af0} id="Vector_2" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M5 4.5H4" id="Vector_3" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M8 6.5H4" id="Vector_4" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M8 8.5H4" id="Vector_5" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Text15() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[40.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[16.5px] items-start relative w-[40.484px]">
        <p className="font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] not-italic relative shrink-0 text-[11px] text-center text-gray-400 text-nowrap whitespace-pre">이용약관</p>
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="[grid-area:2_/_1] content-stretch flex gap-[8px] items-center place-self-stretch relative shrink-0" data-name="Button">
      <Icon14 />
      <Text15 />
    </div>
  );
}

function Icon15() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.p2bec7a00} id="Vector" stroke="var(--stroke-0, #9CA3AF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Text16() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[84.047px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex h-[16.5px] items-start relative w-[84.047px]">
        <p className="font-['Noto_Sans_KR:Regular',sans-serif] leading-[16.5px] not-italic relative shrink-0 text-[11px] text-center text-gray-400 text-nowrap whitespace-pre">개인정보 처리방침</p>
      </div>
    </div>
  );
}

function Button16() {
  return (
    <div className="[grid-area:2_/_2] content-stretch flex gap-[8px] items-center place-self-stretch relative shrink-0" data-name="Button">
      <Icon15 />
      <Text16 />
    </div>
  );
}

function Container12() {
  return (
    <div className="gap-[8px] grid grid-cols-[repeat(2,_minmax(0px,_1fr))] grid-rows-[repeat(2,_minmax(0px,_1fr))] h-[57px] relative shrink-0 w-full" data-name="Container">
      <Button13 />
      <Button14 />
      <Button15 />
      <Button16 />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] leading-[16px] left-[123.05px] not-italic text-[10px] text-center text-gray-300 text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">© 2025 CareGuide</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="box-border content-stretch flex flex-col gap-[12px] h-[93px] items-start pb-0 pt-[8px] px-0 relative shrink-0 w-full" data-name="Container">
      <Container12 />
      <Paragraph />
    </div>
  );
}

function Container14() {
  return (
    <div className="h-[184px] relative shrink-0 w-[279px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1px_0px_0px] border-gray-100 border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[16px] h-[184px] items-start pb-0 pt-[17px] px-[16px] relative w-[279px]">
        <Container11 />
        <Container13 />
      </div>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-white box-border content-stretch flex flex-col h-[803px] items-start left-0 pl-0 pr-px py-0 top-[69px] w-[280px]" data-name="Sidebar">
      <div aria-hidden="true" className="absolute border-[0px_1px_0px_0px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <Navigation />
      <Container14 />
    </div>
  );
}

function CreateDetailedWireframes() {
  return (
    <div className="absolute bg-white h-[931px] left-0 top-0 w-[1489px]" data-name="Create Detailed Wireframes">
      <AppContent />
      <Text5 />
      <ChatPage1 />
      <Header />
      <Sidebar />
      <p className="absolute font-['Noto_Sans_KR:Bold',sans-serif] leading-[31.2px] left-[751px] not-italic text-[20px] text-gray-800 text-nowrap top-[11px] whitespace-pre">AI챗봇</p>
    </div>
  );
}

export default function DesktopChat() {
  return (
    <div className="bg-white relative size-full" data-name="desktop_chat">
      <CreateDetailedWireframes />
    </div>
  );
}