import React, { useState, useEffect, useRef } from 'react';
import { Send, Image as ImageIcon, Stethoscope, Utensils, FileText, ChevronDown } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { MobileHeader } from '../components/MobileHeader';

type AgentTab = 'medical' | 'nutrition' | 'research';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

export function ChatPage() {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<AgentTab>('nutrition'); 
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedProfile, setSelectedProfile] = useState('신장병 환우');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const tabs = [
    { id: 'medical' as AgentTab, label: '의료 복지', icon: Stethoscope },
    { id: 'nutrition' as AgentTab, label: '식이 영양', icon: Utensils },
    { id: 'research' as AgentTab, label: '연구 논문', icon: FileText }
  ];
  
  useEffect(() => {
    const state = location.state as any;
    if (state?.initialMessage) {
      handleSendMessage(state.initialMessage);
    }
    if (state?.tab) {
      setActiveTab(state.tab);
    }
  }, [location]);
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSendMessage = (text?: string) => {
    const messageText = text || message;
    if (!messageText.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: messageText,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setMessage('');
    
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: getAIResponse(activeTab, messageText),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
    }, 1000);
  };
  
  const getAIResponse = (tab: AgentTab, userMessage: string): string => {
    const responses = {
      medical: '신장병 환자를 위한 의료 복지 정보를 안내해드리겠습니다.',
      nutrition: '신장병 환자를 위한 식이 영양 정보를 제공해드립니다.',
      research: '최신 신장병 관련 연구 논문을 검색하고 요약해드립니다.'
    };
    return responses[tab];
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage();
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] bg-white relative">
      {/* Mobile Header */}
      <div className="lg:hidden">
        <MobileHeader 
          title="AI 챗봇" 
          showMenu={true} 
          showProfile={true}
        />
      </div>

      {/* Desktop Tabs */}
      <div className="hidden lg:block bg-white border-b border-gray-200 h-[68.5px] px-[28.5px] pt-[12px]">
        <div className="flex w-full gap-4">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 h-[43.5px] flex items-center justify-center gap-2 rounded-[16.4px] transition-all duration-200 relative group`}
                style={isActive ? {
                  background: '#FFFFFF',
                  color: '#00C9B7', // Teal text for active
                  fontWeight: 'bold',
                  border: '2px solid transparent',
                  backgroundImage: 'linear-gradient(white, white), linear-gradient(to right, #00C9B7, #9F7AEA)',
                  backgroundOrigin: 'border-box',
                  backgroundClip: 'padding-box, border-box',
                  boxShadow: '0px 0px 10px rgba(0, 201, 183, 0.1)' // Slight glow maybe?
                } : {
                  background: '#FFFFFF',
                  color: '#666666',
                  border: '2px solid #E5E7EB'
                }}
              >
                <Icon size={18} strokeWidth={1.5} color={isActive ? '#00C9B7' : '#666666'} />
                <span className="text-[13px]">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto bg-white p-6 lg:p-[28.5px] pb-[180px]">
        {/* Welcome Message */}
        {messages.length === 0 && (
          <div className="mb-6">
             <div className="flex items-center gap-2 mb-1">
               <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M2 1.33333V6C2 6.73333 2.6 7.33333 3.33333 7.33333H6C6.35362 7.33333 6.69276 7.19286 6.94281 6.94281C7.19286 6.69276 7.33333 6.35362 7.33333 6V1.33333" stroke="#4A5565" strokeWidth="1.33" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M4.66667 1.33333V14.6667" stroke="#4A5565" strokeWidth="1.33" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
               </div>
               <span className="text-[12px] text-[#6a7282]">CareGuide AI</span>
             </div>
             <div className="bg-[#f0f4ff] rounded-tr-[12px] rounded-bl-[12px] rounded-br-[12px] p-4 max-w-[500px]">
               <p className="text-[12px] text-black leading-[19.2px]">
                 안녕하세요! 신장병의 {
                   activeTab === 'medical' ? '의료 복지' : 
                   activeTab === 'nutrition' ? '식이 영양' : '연구 논문'
                 } 정보를 알려드리는 케어가이드 챗봇입니다. 무엇이든 물어보세요.
               </p>
             </div>

             {/* Suggestions */}
             <div className="flex gap-3 mt-4">
                <button 
                  onClick={() => handleSendMessage('저칼륨 음식 재료 알려줘')}
                  className="bg-white border border-[#ebebeb] rounded-[8px] px-4 py-2 text-[10px] font-medium text-[#1f1f1f] hover:bg-gray-50"
                >
                  저칼륨 음식 재료 알려줘
                </button>
                <button 
                  onClick={() => handleSendMessage('신장병 환자를 위한 김장 레시피 알려줘')}
                  className="bg-white border border-[#ebebeb] rounded-[8px] px-4 py-2 text-[10px] font-medium text-[#1f1f1f] hover:bg-gray-50"
                >
                  신장병 환자를 위한 김장 레시피 알려줘
                </button>
             </div>
          </div>
        )}

        {/* Message List */}
        {messages.map(msg => (
          <div 
            key={msg.id}
            className={`flex mb-4 ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.type === 'ai' && (
              <div className="flex flex-col items-start max-w-[80%]">
                 <div className="flex items-center gap-2 mb-1">
                   <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M2 1.33333V6C2 6.73333 2.6 7.33333 3.33333 7.33333H6C6.35362 7.33333 6.69276 7.19286 6.94281 6.94281C7.19286 6.69276 7.33333 6.35362 7.33333 6V1.33333" stroke="#4A5565" strokeWidth="1.33" strokeLinecap="round" strokeLinejoin="round"/>
                        <path d="M4.66667 1.33333V14.6667" stroke="#4A5565" strokeWidth="1.33" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                   </div>
                   <span className="text-[12px] text-[#6a7282]">CareGuide AI</span>
                 </div>
                 <div className="bg-[#f0f4ff] rounded-tr-[12px] rounded-bl-[12px] rounded-br-[12px] p-4">
                   <p className="text-[12px] text-black leading-[19.2px] whitespace-pre-wrap">{msg.content}</p>
                 </div>
              </div>
            )}

            {msg.type === 'user' && (
              <div className="bg-[#00C8B4] text-white rounded-tl-[12px] rounded-tr-[12px] rounded-bl-[12px] p-4 max-w-[80%]">
                <p className="text-[12px] leading-[19.2px] whitespace-pre-wrap">{msg.content}</p>
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Input Area - Positioned at the bottom with enough spacing from content */}
      <div className="absolute bottom-6 left-[28.5px] right-[28.5px] z-20">
        <div className="bg-white rounded-[16px] border border-[#e0e0e0] p-[9px] shadow-sm w-full">
           {/* Top Row: Icon + Input + Send Button */}
           <form onSubmit={handleSubmit} className="flex items-center gap-2 mb-2 relative h-[40px]">
               <button 
                  type="button" 
                  className="w-8 h-8 flex items-center justify-center rounded-full text-[#99A1AF] hover:bg-gray-100 flex-shrink-0"
                >
                  <ImageIcon size={20} strokeWidth={1.66} />
               </button>
               
               <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="메시지를 입력하세요"
                  className="flex-1 h-full bg-transparent outline-none text-[14px] text-[#1E2939] placeholder-[rgba(30,41,57,0.5)]"
               />
               
               <button
                  type="submit"
                  disabled={!message.trim()}
                  className="w-8 h-8 flex items-center justify-center rounded-full transition-colors flex-shrink-0"
                  style={{
                     background: message.trim() ? '#00C9B7' : '#F3F4F6'
                  }}
               >
                  <Send size={14} color={message.trim() ? '#FFFFFF' : '#9CA3AF'} />
               </button>
           </form>
           
           {/* Bottom Row: Divider + Custom Info Dropdown */}
           <div className="border-t border-gray-100 pt-[4px] flex items-center justify-between h-[33.5px]">
              <div className="flex items-center gap-2">
                 <span className="text-[11px] text-gray-500">맞춤 정보:</span>
                 <div className="relative flex items-center gap-1 cursor-pointer">
                    <span className="text-[11px] text-[#00c8b4] font-medium">{selectedProfile}</span>
                    <ChevronDown size={12} color="#00C8B4" />
                    <select 
                      value={selectedProfile}
                      onChange={(e) => setSelectedProfile(e.target.value)}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    >
                      <option value="신장병 환우">신장병 환우</option>
                      <option value="일반인">일반인(간병인)</option>
                      <option value="연구자">연구자</option>
                    </select>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
