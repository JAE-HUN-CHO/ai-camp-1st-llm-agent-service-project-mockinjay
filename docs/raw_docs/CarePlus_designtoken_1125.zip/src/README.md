# CarePlus - 신장병 환자를 위한 AI 케어 플랫폼

만성신장병 환자와 가족을 위한 종합 건강 관리 웹 애플리케이션

## 🎯 프로젝트 개요

CarePlus는 신장병 환자들이 일상적인 건강 관리를 효과적으로 할 수 있도록 돕는 AI 기반 플랫폼입니다. 부드럽고 따뜻한 힐링 느낌의 디자인으로 환자들에게 편안한 경험을 제공합니다.

## ✨ 주요 기능

### 1. AI 챗봇
- **의료 복지**: 건강보험 혜택, 장애인 등록, 의료비 지원 안내
- **식이 영양**: 저칼륨, 저인, 저단백 식단 추천 및 조언
- **연구 논문**: PubMed 기반 최신 연구 논문 검색 및 요약

### 2. 식단케어
- **뉴트리 코치**: 영양소별 식품 정보 (칼륨, 인, 단백질, 열량)
- **식단 로그**: 일별 식사 기록 및 영양소 섭취 추적 (CRUD)

### 3. 퀴즈미션
- 건강 지식 테스트
- 포인트 적립 시스템
- 학습 기반 게이미피케이션

### 4. 커뮤니티
- 환우 간 경험 공유
- 게시글 작성/수정/삭제 (CRUD)
- 좋아요, 댓글, 공유 기능

### 5. 트렌드
- 신장병 관련 최신 뉴스
- 실시간 인기 키워드
- PubMed 연구 트렌드 시계열 그래프

## 🎨 디자인 시스템

### 컬러 팔레트
- **Primary**: #00C8B4
- **Primary Dark**: #00A89A
- **Accent Purple**: #9F7AEA
- **Success**: #00C8A9

### 타이포그래피
- **한글**: Noto Sans KR (400, 500, 600, 700)
- **영문 (로고)**: Inter (400, 500, 600, 700)

### 디자인 토큰
CSS Variables를 통한 일관된 스타일 관리:
- 색상 (Primary, Text, Line, Background)
- 그림자 (Shadow)
- 버튼 variants (Primary, Secondary, Ghost)
- 입력 필드 스타일 (Default, Focus, Disabled)
- 카드 컴포넌트
- 채팅 버블 (User, AI)

## 📱 반응형 디자인

### Desktop/Tablet (1024px+)
- 좌측 고정 사이드바 (280px)
- 헤더 상단 고정

### Mobile (~1023px)
- 햄버거 메뉴 (Drawer)
- 하단 탭 네비게이션 (5개 메뉴)

## 🗂️ IA (Information Architecture)

```
/main - 스플래시 홈
/chat - AI 챗봇
/diet-care - 식단케어
  /diet-care/nutri-coach - 뉴트리 코치
  /diet-care/diet-log - 식단 로그
/quiz - 퀴즈미션
/community - 커뮤니티
  /community/detail-{id} - 게시글 상세
/trends - 트렌드
/mypage - 마이페이지
  /mypage/profile - 프로필
    /mypage/profile/kidney-disease-stage - 질환 단계
  /mypage/test-results - 병원검사결과
/notification - 알림
/support - 도움말 및 지원
/terms-and-conditions - 이용약관
/privacy-policy - 개인정보처리방침
/cookie-consent - 쿠키 정책
/login - 로그인
/signup - 회원가입
```

## 🚀 기술 스택

- **Framework**: React 18 + TypeScript
- **Routing**: React Router v6
- **Styling**: Tailwind CSS v4 + CSS Variables
- **Charts**: Recharts
- **Icons**: Lucide React
- **Build Tool**: Vite

## 🔐 접근성 & SEO

- 모든 이미지에 alt 텍스트
- 시맨틱 HTML 사용
- ARIA 레이블 적용
- 구조화된 데이터 (Schema.org)
- Open Graph & Twitter Card 메타 태그

## 📦 컴포넌트 구조

```
/components
  - Logo.tsx - 브랜드 로고
  - Header.tsx - 헤더 (알림, 프로필)
  - Sidebar.tsx - 데스크톱 사이드바
  - MobileNav.tsx - 모바일 하단 탭
  - Drawer.tsx - 모바일 메뉴 서랍

/pages
  - MainPage.tsx - 스플래시 홈
  - ChatPage.tsx - AI 챗봇
  - DietCarePage.tsx - 식단케어 허브
  - NutriCoachPage.tsx - 영양소 가이드
  - DietLogPage.tsx - 식단 기록
  - QuizPage.tsx - 퀴즈 미션
  - CommunityPage.tsx - 커뮤니티
  - TrendsPage.tsx - 트렌드
  - MyPage.tsx - 마이페이지
  - ProfilePage.tsx - 프로필 관리
  - LoginPage.tsx - 로그인
  - SignupPage.tsx - 회원가입
```

## 🎯 브랜드 아이덴티티

### 대상
만성신장병 장기 투병 환자와 가족

### Tone & Manner
- ✅ 부드럽고 힐링되는 따뜻한 느낌
- ❌ 딱딱함, 차가움, 기계적 장식, 네온 톤 금지

## 📄 라이선스

© 2025 CarePlus. All rights reserved.
