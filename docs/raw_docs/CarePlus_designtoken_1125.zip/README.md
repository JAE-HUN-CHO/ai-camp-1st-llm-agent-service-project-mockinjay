
  # Create Detailed Wireframes

  This is a code bundle for Create Detailed Wireframes. The original project is available at https://www.figma.com/design/JhmioiVItRzsG76N1rYU0o/Create-Detailed-Wireframes.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  